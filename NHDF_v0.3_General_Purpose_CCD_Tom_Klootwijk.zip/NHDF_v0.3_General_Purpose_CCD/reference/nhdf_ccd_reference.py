"""NHDF Version 0.3 elementary Continuous Collision Detection reference.

This module is deliberately small, deterministic, and dependency-free.  It is
an executable semantics scaffold for a subset of the Version 0.3 contract:

* typed query/result/status/certificate records;
* analytic linear sphere-sphere CCD;
* analytic linear sphere-plane CCD;
* translating AABB-AABB slab CCD;
* conservative swept-AABB broad phase;
* a generic bounded conservative-advancement loop;
* explicit UNSUPPORTED / INDETERMINATE failure paths.

It is NOT a production implementation of the complete convex, rotating rigid,
triangle-mesh, deformable, self-collision, or simultaneous-contact profiles.
Those backends are specified in the PDF but intentionally not faked here.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
import math
from typing import Callable, Iterable, Optional, Sequence


_EPS = 1.0e-15


@dataclass(frozen=True, slots=True)
class Vec3:
    x: float
    y: float
    z: float

    def __add__(self, other: "Vec3") -> "Vec3":
        return Vec3(self.x + other.x, self.y + other.y, self.z + other.z)

    def __sub__(self, other: "Vec3") -> "Vec3":
        return Vec3(self.x - other.x, self.y - other.y, self.z - other.z)

    def __mul__(self, scalar: float) -> "Vec3":
        return Vec3(self.x * scalar, self.y * scalar, self.z * scalar)

    __rmul__ = __mul__

    def __truediv__(self, scalar: float) -> "Vec3":
        if abs(scalar) <= _EPS:
            raise ZeroDivisionError("Vec3 division by near-zero scalar")
        return Vec3(self.x / scalar, self.y / scalar, self.z / scalar)

    def __neg__(self) -> "Vec3":
        return Vec3(-self.x, -self.y, -self.z)

    def dot(self, other: "Vec3") -> float:
        return self.x * other.x + self.y * other.y + self.z * other.z

    def norm_sq(self) -> float:
        return self.dot(self)

    def norm(self) -> float:
        return math.sqrt(self.norm_sq())

    def normalized(self, fallback: Optional["Vec3"] = None) -> "Vec3":
        n = self.norm()
        if n <= _EPS:
            if fallback is not None:
                return fallback
            raise ValueError("Cannot normalize a near-zero vector")
        return self / n

    def component(self, axis: int) -> float:
        if axis == 0:
            return self.x
        if axis == 1:
            return self.y
        if axis == 2:
            return self.z
        raise IndexError(axis)

    def to_list(self) -> list[float]:
        return [self.x, self.y, self.z]


ZERO = Vec3(0.0, 0.0, 0.0)


class ShapeKind(str, Enum):
    SPHERE = "SPHERE"
    PLANE = "PLANE"
    AABB = "AABB"
    UNKNOWN = "UNKNOWN"


class MotionKind(str, Enum):
    STATIC = "STATIC"
    LINEAR_TRANSLATION = "LINEAR_TRANSLATION"
    UNSUPPORTED = "UNSUPPORTED"


class ResultStatus(str, Enum):
    CLEAR_CERTIFIED = "CLEAR_CERTIFIED"
    HIT_CERTIFIED = "HIT_CERTIFIED"
    HIT_CONSERVATIVE = "HIT_CONSERVATIVE"
    INITIAL_CONTACT = "INITIAL_CONTACT"
    INITIAL_OVERLAP = "INITIAL_OVERLAP"
    INDETERMINATE = "INDETERMINATE"
    UNSUPPORTED = "UNSUPPORTED"
    NUMERIC_FAILURE = "NUMERIC_FAILURE"
    RESOURCE_FAILURE = "RESOURCE_FAILURE"


class CertificateClass(str, Enum):
    EXACT_PREDICATE = "EXACT_PREDICATE"
    ANALYTIC_BOUNDED = "ANALYTIC_BOUNDED"
    INCLUSION = "INCLUSION"
    CONSERVATIVE_ADVANCEMENT = "CONSERVATIVE_ADVANCEMENT"
    APPROXIMATE = "APPROXIMATE"
    NONE = "NONE"


@dataclass(frozen=True, slots=True)
class TimeInterval:
    start: float
    end: float

    def __post_init__(self) -> None:
        if not (math.isfinite(self.start) and math.isfinite(self.end)):
            raise ValueError("Time interval endpoints must be finite")
        if self.end < self.start:
            raise ValueError("Time interval must satisfy end >= start")

    @property
    def duration(self) -> float:
        return self.end - self.start

    def clamp(self, t: float) -> float:
        return min(max(t, self.start), self.end)


@dataclass(frozen=True, slots=True)
class LinearMotion:
    position_at_zero: Vec3
    velocity: Vec3 = ZERO

    @property
    def kind(self) -> MotionKind:
        return MotionKind.STATIC if self.velocity.norm_sq() <= _EPS else MotionKind.LINEAR_TRANSLATION

    def position(self, t: float) -> Vec3:
        return self.position_at_zero + self.velocity * t


@dataclass(frozen=True, slots=True)
class Sphere:
    radius: float

    def __post_init__(self) -> None:
        if not math.isfinite(self.radius) or self.radius < 0.0:
            raise ValueError("Sphere radius must be finite and non-negative")

    @property
    def kind(self) -> ShapeKind:
        return ShapeKind.SPHERE


@dataclass(frozen=True, slots=True)
class Plane:
    """One-sided plane n dot x = offset; valid free half-space is n dot x >= offset."""

    normal: Vec3
    offset: float

    def __post_init__(self) -> None:
        if not math.isfinite(self.offset):
            raise ValueError("Plane offset must be finite")
        n = self.normal.norm()
        if n <= _EPS:
            raise ValueError("Plane normal must be non-zero")
        object.__setattr__(self, "normal", self.normal / n)
        object.__setattr__(self, "offset", self.offset / n)

    @property
    def kind(self) -> ShapeKind:
        return ShapeKind.PLANE


@dataclass(frozen=True, slots=True)
class AABB:
    half_extent: Vec3

    def __post_init__(self) -> None:
        if min(self.half_extent.x, self.half_extent.y, self.half_extent.z) < 0.0:
            raise ValueError("AABB half extents must be non-negative")
        if not all(math.isfinite(v) for v in self.half_extent.to_list()):
            raise ValueError("AABB half extents must be finite")

    @property
    def kind(self) -> ShapeKind:
        return ShapeKind.AABB


Shape = Sphere | Plane | AABB


@dataclass(frozen=True, slots=True)
class MovingObject:
    object_id: str
    shape: Shape
    motion: LinearMotion

    @property
    def shape_kind(self) -> ShapeKind:
        return self.shape.kind


@dataclass(frozen=True, slots=True)
class CCDPolicy:
    minimum_separation: float = 0.0
    time_tolerance: float = 1.0e-9
    spatial_tolerance: float = 1.0e-9
    max_iterations: int = 128
    safety_factor: float = 0.8
    minimum_time_progress: float = 1.0e-12

    def __post_init__(self) -> None:
        if self.minimum_separation < 0.0:
            raise ValueError("minimum_separation must be >= 0")
        if self.time_tolerance <= 0.0 or self.spatial_tolerance <= 0.0:
            raise ValueError("tolerances must be > 0")
        if self.max_iterations <= 0:
            raise ValueError("max_iterations must be > 0")
        if not (0.0 < self.safety_factor < 1.0):
            raise ValueError("safety_factor must lie in (0, 1)")
        if self.minimum_time_progress <= 0.0:
            raise ValueError("minimum_time_progress must be > 0")


@dataclass(frozen=True, slots=True)
class CCDQuery:
    object_a: MovingObject
    object_b: MovingObject
    interval: TimeInterval
    policy: CCDPolicy = field(default_factory=CCDPolicy)
    query_id: str = "query"


@dataclass(frozen=True, slots=True)
class CCDResult:
    status: ResultStatus
    toi: Optional[TimeInterval] = None
    certificate: CertificateClass = CertificateClass.NONE
    object_a: str = ""
    object_b: str = ""
    witness_a: Optional[Vec3] = None
    witness_b: Optional[Vec3] = None
    normal_b_to_a: Optional[Vec3] = None
    iterations: int = 0
    diagnostic: str = ""
    flags: tuple[str, ...] = ()

    @property
    def is_failure(self) -> bool:
        return self.status in {
            ResultStatus.INDETERMINATE,
            ResultStatus.UNSUPPORTED,
            ResultStatus.NUMERIC_FAILURE,
            ResultStatus.RESOURCE_FAILURE,
        }

    def to_dict(self) -> dict[str, object]:
        data = asdict(self)
        data["status"] = self.status.value
        data["certificate"] = self.certificate.value
        if self.toi is not None:
            data["toi"] = {"start": self.toi.start, "end": self.toi.end}
        for key in ("witness_a", "witness_b", "normal_b_to_a"):
            value = getattr(self, key)
            data[key] = None if value is None else value.to_list()
        data["flags"] = list(self.flags)
        return data


@dataclass(frozen=True, slots=True)
class Bounds3:
    minimum: Vec3
    maximum: Vec3

    def overlaps(self, other: "Bounds3") -> bool:
        return (
            self.minimum.x <= other.maximum.x
            and self.maximum.x >= other.minimum.x
            and self.minimum.y <= other.maximum.y
            and self.maximum.y >= other.minimum.y
            and self.minimum.z <= other.maximum.z
            and self.maximum.z >= other.minimum.z
        )


@dataclass(frozen=True, slots=True)
class BroadPhaseDecision:
    object_a: str
    object_b: str
    candidate: bool
    reason: str


@dataclass(frozen=True, slots=True)
class SeparationSample:
    gap: float
    normal_b_to_a: Optional[Vec3]
    witness_a: Optional[Vec3]
    witness_b: Optional[Vec3]


SeparationOracle = Callable[[float], SeparationSample]
ClosingBound = Callable[[float], float]


def _result(query: CCDQuery, status: ResultStatus, **kwargs: object) -> CCDResult:
    return CCDResult(
        status=status,
        object_a=query.object_a.object_id,
        object_b=query.object_b.object_id,
        **kwargs,
    )


def _toi_interval(query: CCDQuery, t: float) -> TimeInterval:
    tol = query.policy.time_tolerance
    return TimeInterval(query.interval.clamp(t - tol), query.interval.clamp(t + tol))


def _safe_quadratic_roots(a: float, b: float, c: float) -> tuple[float, ...]:
    """Return sorted real roots using a cancellation-resistant formula."""
    if abs(a) <= _EPS:
        if abs(b) <= _EPS:
            return ()
        return (-c / b,)
    disc = b * b - 4.0 * a * c
    scale = max(b * b, abs(4.0 * a * c), 1.0)
    if disc < -64.0 * math.ulp(scale):
        return ()
    disc = max(0.0, disc)
    sqrt_disc = math.sqrt(disc)
    if sqrt_disc <= _EPS:
        return (-0.5 * b / a,)
    q = -0.5 * (b + math.copysign(sqrt_disc, b))
    if abs(q) <= _EPS:
        r1 = (-b - sqrt_disc) / (2.0 * a)
        r2 = (-b + sqrt_disc) / (2.0 * a)
    else:
        r1 = q / a
        r2 = c / q
    return tuple(sorted((r1, r2)))


def sphere_sphere_toi(query: CCDQuery) -> CCDResult:
    if not isinstance(query.object_a.shape, Sphere) or not isinstance(query.object_b.shape, Sphere):
        return _result(query, ResultStatus.UNSUPPORTED, diagnostic="sphere_sphere_toi requires two spheres")

    t0 = query.interval.start
    duration = query.interval.duration
    ca0 = query.object_a.motion.position(t0)
    cb0 = query.object_b.motion.position(t0)
    p = ca0 - cb0
    v = query.object_a.motion.velocity - query.object_b.motion.velocity
    radius = (
        query.object_a.shape.radius
        + query.object_b.shape.radius
        + query.policy.minimum_separation
    )
    c = p.norm_sq() - radius * radius
    tol = query.policy.spatial_tolerance

    if c < -tol:
        n = p.normalized(Vec3(1.0, 0.0, 0.0))
        return _result(
            query,
            ResultStatus.INITIAL_OVERLAP,
            toi=TimeInterval(t0, t0),
            certificate=CertificateClass.ANALYTIC_BOUNDED,
            witness_a=ca0 - n * query.object_a.shape.radius,
            witness_b=cb0 + n * query.object_b.shape.radius,
            normal_b_to_a=n,
            diagnostic="sphere pair begins inside requested separation margin",
        )
    if abs(c) <= tol:
        n = p.normalized((-v).normalized(Vec3(1.0, 0.0, 0.0)))
        return _result(
            query,
            ResultStatus.INITIAL_CONTACT,
            toi=TimeInterval(t0, t0),
            certificate=CertificateClass.ANALYTIC_BOUNDED,
            witness_a=ca0 - n * query.object_a.shape.radius,
            witness_b=cb0 + n * query.object_b.shape.radius,
            normal_b_to_a=n,
            diagnostic="sphere pair begins on requested contact boundary",
        )

    a = v.norm_sq()
    if a <= _EPS:
        return _result(
            query,
            ResultStatus.CLEAR_CERTIFIED,
            certificate=CertificateClass.ANALYTIC_BOUNDED,
            diagnostic="positive separation and zero relative linear velocity",
        )

    b = 2.0 * p.dot(v)
    roots = _safe_quadratic_roots(a, b, c)
    local_hit = next((r for r in roots if -query.policy.time_tolerance <= r <= duration + query.policy.time_tolerance), None)
    if local_hit is None:
        return _result(
            query,
            ResultStatus.CLEAR_CERTIFIED,
            certificate=CertificateClass.ANALYTIC_BOUNDED,
            diagnostic="quadratic has no admissible root in interval",
        )

    local_hit = min(max(local_hit, 0.0), duration)
    hit_t = t0 + local_hit
    ca = query.object_a.motion.position(hit_t)
    cb = query.object_b.motion.position(hit_t)
    n = (ca - cb).normalized((-v).normalized(Vec3(1.0, 0.0, 0.0)))
    return _result(
        query,
        ResultStatus.HIT_CERTIFIED,
        toi=_toi_interval(query, hit_t),
        certificate=CertificateClass.ANALYTIC_BOUNDED,
        witness_a=ca - n * query.object_a.shape.radius,
        witness_b=cb + n * query.object_b.shape.radius,
        normal_b_to_a=n,
        diagnostic="earliest admissible analytic sphere-sphere root",
    )


def sphere_plane_toi(query: CCDQuery) -> CCDResult:
    if not isinstance(query.object_a.shape, Sphere) or not isinstance(query.object_b.shape, Plane):
        return _result(query, ResultStatus.UNSUPPORTED, diagnostic="sphere_plane_toi requires sphere as A and plane as B")
    if query.object_b.motion.kind is not MotionKind.STATIC:
        return _result(query, ResultStatus.UNSUPPORTED, diagnostic="reference plane backend is static-only")

    sphere = query.object_a.shape
    plane = query.object_b.shape
    t0 = query.interval.start
    center0 = query.object_a.motion.position(t0)
    gap0 = plane.normal.dot(center0) - plane.offset - sphere.radius - query.policy.minimum_separation
    tol = query.policy.spatial_tolerance

    witness_a0 = center0 - plane.normal * sphere.radius
    witness_b0 = witness_a0 - plane.normal * query.policy.minimum_separation
    if gap0 < -tol:
        return _result(
            query,
            ResultStatus.INITIAL_OVERLAP,
            toi=TimeInterval(t0, t0),
            certificate=CertificateClass.ANALYTIC_BOUNDED,
            witness_a=witness_a0,
            witness_b=witness_b0,
            normal_b_to_a=plane.normal,
            diagnostic="sphere begins beyond one-sided plane margin",
        )
    if abs(gap0) <= tol:
        return _result(
            query,
            ResultStatus.INITIAL_CONTACT,
            toi=TimeInterval(t0, t0),
            certificate=CertificateClass.ANALYTIC_BOUNDED,
            witness_a=witness_a0,
            witness_b=witness_b0,
            normal_b_to_a=plane.normal,
            diagnostic="sphere begins on one-sided plane contact boundary",
        )

    speed = plane.normal.dot(query.object_a.motion.velocity)
    if speed >= -_EPS:
        return _result(
            query,
            ResultStatus.CLEAR_CERTIFIED,
            certificate=CertificateClass.ANALYTIC_BOUNDED,
            diagnostic="sphere is stationary or moving away from one-sided plane",
        )

    local_hit = -gap0 / speed
    if local_hit < -query.policy.time_tolerance or local_hit > query.interval.duration + query.policy.time_tolerance:
        return _result(
            query,
            ResultStatus.CLEAR_CERTIFIED,
            certificate=CertificateClass.ANALYTIC_BOUNDED,
            diagnostic="plane root lies outside interval",
        )

    hit_t = t0 + min(max(local_hit, 0.0), query.interval.duration)
    center = query.object_a.motion.position(hit_t)
    wa = center - plane.normal * sphere.radius
    wb = wa - plane.normal * query.policy.minimum_separation
    return _result(
        query,
        ResultStatus.HIT_CERTIFIED,
        toi=_toi_interval(query, hit_t),
        certificate=CertificateClass.ANALYTIC_BOUNDED,
        witness_a=wa,
        witness_b=wb,
        normal_b_to_a=plane.normal,
        diagnostic="analytic sphere-plane root",
    )


def aabb_aabb_toi(query: CCDQuery) -> CCDResult:
    if not isinstance(query.object_a.shape, AABB) or not isinstance(query.object_b.shape, AABB):
        return _result(query, ResultStatus.UNSUPPORTED, diagnostic="aabb_aabb_toi requires two AABBs")

    t0 = query.interval.start
    duration = query.interval.duration
    ca = query.object_a.motion.position(t0)
    cb = query.object_b.motion.position(t0)
    rel = ca - cb
    vel = query.object_a.motion.velocity - query.object_b.motion.velocity
    margin = query.policy.minimum_separation
    ext = query.object_a.shape.half_extent + query.object_b.shape.half_extent + Vec3(margin, margin, margin)
    tol = query.policy.spatial_tolerance

    deltas = [abs(rel.component(axis)) - ext.component(axis) for axis in range(3)]
    if max(deltas) <= tol:
        status = ResultStatus.INITIAL_CONTACT if max(deltas) >= -tol else ResultStatus.INITIAL_OVERLAP
        axis = max(range(3), key=lambda i: deltas[i])
        sign = 1.0 if rel.component(axis) >= 0.0 else -1.0
        normal = Vec3(sign if axis == 0 else 0.0, sign if axis == 1 else 0.0, sign if axis == 2 else 0.0)
        return _result(
            query,
            status,
            toi=TimeInterval(t0, t0),
            certificate=CertificateClass.ANALYTIC_BOUNDED,
            normal_b_to_a=normal,
            witness_a=ca,
            witness_b=cb,
            diagnostic="translating AABBs begin overlapping/touching expanded slabs",
        )

    entry = 0.0
    exit_ = duration
    entry_axis = -1
    for axis in range(3):
        p = rel.component(axis)
        v = vel.component(axis)
        h = ext.component(axis)
        if abs(v) <= _EPS:
            if abs(p) > h:
                return _result(
                    query,
                    ResultStatus.CLEAR_CERTIFIED,
                    certificate=CertificateClass.ANALYTIC_BOUNDED,
                    diagnostic=f"separated stationary slab on axis {axis}",
                )
            continue
        t_a = (-h - p) / v
        t_b = (h - p) / v
        axis_entry = min(t_a, t_b)
        axis_exit = max(t_a, t_b)
        if axis_entry > entry:
            entry = axis_entry
            entry_axis = axis
        exit_ = min(exit_, axis_exit)
        if entry - query.policy.time_tolerance > exit_:
            return _result(
                query,
                ResultStatus.CLEAR_CERTIFIED,
                certificate=CertificateClass.ANALYTIC_BOUNDED,
                diagnostic="slab time intervals do not overlap",
            )

    if exit_ < -query.policy.time_tolerance or entry > duration + query.policy.time_tolerance:
        return _result(
            query,
            ResultStatus.CLEAR_CERTIFIED,
            certificate=CertificateClass.ANALYTIC_BOUNDED,
            diagnostic="expanded AABB overlap interval lies outside query interval",
        )

    local_hit = min(max(entry, 0.0), duration)
    hit_t = t0 + local_hit
    ca_hit = query.object_a.motion.position(hit_t)
    cb_hit = query.object_b.motion.position(hit_t)
    axis = 0 if entry_axis < 0 else entry_axis
    rel_hit = (ca_hit - cb_hit).component(axis)
    sign = 1.0 if rel_hit >= 0.0 else -1.0
    normal = Vec3(sign if axis == 0 else 0.0, sign if axis == 1 else 0.0, sign if axis == 2 else 0.0)
    return _result(
        query,
        ResultStatus.HIT_CERTIFIED,
        toi=_toi_interval(query, hit_t),
        certificate=CertificateClass.ANALYTIC_BOUNDED,
        witness_a=ca_hit,
        witness_b=cb_hit,
        normal_b_to_a=normal,
        diagnostic="earliest overlap of three translating expanded slabs",
    )


def swept_bounds(obj: MovingObject, interval: TimeInterval, margin: float = 0.0) -> Optional[Bounds3]:
    if margin < 0.0:
        raise ValueError("margin must be non-negative")
    p0 = obj.motion.position(interval.start)
    p1 = obj.motion.position(interval.end)

    if isinstance(obj.shape, Sphere):
        h = Vec3(obj.shape.radius + margin, obj.shape.radius + margin, obj.shape.radius + margin)
    elif isinstance(obj.shape, AABB):
        h = obj.shape.half_extent + Vec3(margin, margin, margin)
    elif isinstance(obj.shape, Plane):
        return None  # Unbounded; pair must be handled outside finite AABB pruning.
    else:
        return None

    minimum = Vec3(min(p0.x, p1.x) - h.x, min(p0.y, p1.y) - h.y, min(p0.z, p1.z) - h.z)
    maximum = Vec3(max(p0.x, p1.x) + h.x, max(p0.y, p1.y) + h.y, max(p0.z, p1.z) + h.z)
    return Bounds3(minimum, maximum)


def broad_phase(objects: Sequence[MovingObject], interval: TimeInterval, margin: float = 0.0) -> tuple[list[tuple[int, int]], list[BroadPhaseDecision]]:
    bounds = [swept_bounds(obj, interval, margin) for obj in objects]
    pairs: list[tuple[int, int]] = []
    decisions: list[BroadPhaseDecision] = []
    for i in range(len(objects)):
        for j in range(i + 1, len(objects)):
            bi, bj = bounds[i], bounds[j]
            if bi is None or bj is None:
                candidate = True
                reason = "unbounded or unsupported finite bound retained conservatively"
            else:
                candidate = bi.overlaps(bj)
                reason = "conservative swept bounds overlap" if candidate else "disjoint conservative swept bounds"
            decisions.append(BroadPhaseDecision(objects[i].object_id, objects[j].object_id, candidate, reason))
            if candidate:
                pairs.append((i, j))
    return pairs, decisions


def conservative_advancement(
    *,
    object_a: str,
    object_b: str,
    interval: TimeInterval,
    policy: CCDPolicy,
    separation: SeparationOracle,
    closing_speed_bound: ClosingBound,
) -> CCDResult:
    """Bounded conservative advancement for a caller-supplied separation contract.

    `separation(t).gap` must be a conservative lower bound on actual separation
    minus `minimum_separation`. `closing_speed_bound(t)` must upper-bound the
    rate at which that gap can close over the proposed step.  The routine cannot
    verify those promises; an invalid oracle invalidates the certificate.
    """

    t = interval.start
    previous_t = t
    first = separation(t)
    tol = policy.spatial_tolerance
    if not math.isfinite(first.gap):
        return CCDResult(ResultStatus.NUMERIC_FAILURE, object_a=object_a, object_b=object_b, diagnostic="non-finite initial gap")
    if first.gap < -tol:
        return CCDResult(
            ResultStatus.INITIAL_OVERLAP,
            toi=TimeInterval(t, t),
            certificate=CertificateClass.CONSERVATIVE_ADVANCEMENT,
            object_a=object_a,
            object_b=object_b,
            witness_a=first.witness_a,
            witness_b=first.witness_b,
            normal_b_to_a=first.normal_b_to_a,
            diagnostic="initial conservative separation lower bound is negative",
        )
    if abs(first.gap) <= tol:
        return CCDResult(
            ResultStatus.INITIAL_CONTACT,
            toi=TimeInterval(t, t),
            certificate=CertificateClass.CONSERVATIVE_ADVANCEMENT,
            object_a=object_a,
            object_b=object_b,
            witness_a=first.witness_a,
            witness_b=first.witness_b,
            normal_b_to_a=first.normal_b_to_a,
            diagnostic="initial conservative separation is within tolerance",
        )

    sample = first
    for iteration in range(1, policy.max_iterations + 1):
        bound = closing_speed_bound(t)
        if not math.isfinite(bound) or bound < 0.0:
            return CCDResult(
                ResultStatus.INDETERMINATE,
                object_a=object_a,
                object_b=object_b,
                iterations=iteration,
                diagnostic="invalid closing-speed bound",
            )
        if bound <= _EPS:
            return CCDResult(
                ResultStatus.CLEAR_CERTIFIED,
                certificate=CertificateClass.CONSERVATIVE_ADVANCEMENT,
                object_a=object_a,
                object_b=object_b,
                iterations=iteration,
                diagnostic="positive separation with certified zero closing rate",
            )

        safe_gap = max(sample.gap - tol, 0.0)
        dt = policy.safety_factor * safe_gap / bound
        remaining = interval.end - t
        if remaining <= policy.time_tolerance:
            return CCDResult(
                ResultStatus.CLEAR_CERTIFIED,
                certificate=CertificateClass.CONSERVATIVE_ADVANCEMENT,
                object_a=object_a,
                object_b=object_b,
                iterations=iteration,
                diagnostic="reached interval end with positive conservative gap",
            )
        if dt >= remaining:
            # The valid closing bound proves the gap cannot close over `remaining`.
            return CCDResult(
                ResultStatus.CLEAR_CERTIFIED,
                certificate=CertificateClass.CONSERVATIVE_ADVANCEMENT,
                object_a=object_a,
                object_b=object_b,
                iterations=iteration,
                diagnostic="remaining interval lies within certified safe advancement",
            )
        if dt < policy.minimum_time_progress:
            # Current gap is at most the spatial tolerance plus a sub-progress
            # remainder.  Include enough time for the certified closing bound
            # to consume that tolerance, rather than returning a point that can
            # lie strictly before the true contact.
            enclosure_dt = max(
                policy.time_tolerance,
                policy.minimum_time_progress,
                max(sample.gap, 0.0) / max(bound, _EPS),
            )
            upper = min(interval.end, t + enclosure_dt)
            return CCDResult(
                ResultStatus.HIT_CONSERVATIVE,
                toi=TimeInterval(previous_t, upper),
                certificate=CertificateClass.CONSERVATIVE_ADVANCEMENT,
                object_a=object_a,
                object_b=object_b,
                witness_a=sample.witness_a,
                witness_b=sample.witness_b,
                normal_b_to_a=sample.normal_b_to_a,
                iterations=iteration,
                diagnostic="advancement fell below progress floor near contact",
            )

        previous_t = t
        t += dt
        sample = separation(t)
        if not math.isfinite(sample.gap):
            return CCDResult(
                ResultStatus.NUMERIC_FAILURE,
                object_a=object_a,
                object_b=object_b,
                iterations=iteration,
                diagnostic="non-finite separation sample",
            )
        if sample.gap <= tol:
            return CCDResult(
                ResultStatus.HIT_CONSERVATIVE,
                toi=TimeInterval(previous_t, min(interval.end, t + policy.time_tolerance)),
                certificate=CertificateClass.CONSERVATIVE_ADVANCEMENT,
                object_a=object_a,
                object_b=object_b,
                witness_a=sample.witness_a,
                witness_b=sample.witness_b,
                normal_b_to_a=sample.normal_b_to_a,
                iterations=iteration,
                diagnostic="contact tolerance reached by conservative advancement",
            )

    return CCDResult(
        ResultStatus.INDETERMINATE,
        object_a=object_a,
        object_b=object_b,
        iterations=policy.max_iterations,
        diagnostic="conservative advancement iteration budget exhausted",
    )


def moving_sphere_static_sphere_oracle(
    moving: MovingObject,
    static: MovingObject,
    minimum_separation: float = 0.0,
) -> tuple[SeparationOracle, ClosingBound]:
    if not isinstance(moving.shape, Sphere) or not isinstance(static.shape, Sphere):
        raise TypeError("oracle requires two spheres")
    if static.motion.kind is not MotionKind.STATIC:
        raise ValueError("second sphere must be static for this simple oracle")
    radius_sum = moving.shape.radius + static.shape.radius + minimum_separation

    def separation(t: float) -> SeparationSample:
        ca = moving.motion.position(t)
        cb = static.motion.position(t)
        delta = ca - cb
        distance = delta.norm()
        normal = delta.normalized((-moving.motion.velocity).normalized(Vec3(1.0, 0.0, 0.0)))
        return SeparationSample(
            gap=distance - radius_sum,
            normal_b_to_a=normal,
            witness_a=ca - normal * moving.shape.radius,
            witness_b=cb + normal * static.shape.radius,
        )

    speed_bound = moving.motion.velocity.norm()

    def closing_bound(_: float) -> float:
        return speed_bound

    return separation, closing_bound


def dispatch(query: CCDQuery) -> CCDResult:
    a, b = query.object_a.shape, query.object_b.shape
    try:
        if isinstance(a, Sphere) and isinstance(b, Sphere):
            return sphere_sphere_toi(query)
        if isinstance(a, Sphere) and isinstance(b, Plane):
            return sphere_plane_toi(query)
        if isinstance(a, Plane) and isinstance(b, Sphere):
            swapped = CCDQuery(query.object_b, query.object_a, query.interval, query.policy, query.query_id)
            r = sphere_plane_toi(swapped)
            return CCDResult(
                status=r.status,
                toi=r.toi,
                certificate=r.certificate,
                object_a=query.object_a.object_id,
                object_b=query.object_b.object_id,
                witness_a=r.witness_b,
                witness_b=r.witness_a,
                normal_b_to_a=None if r.normal_b_to_a is None else -r.normal_b_to_a,
                iterations=r.iterations,
                diagnostic="swapped plane-sphere dispatch: " + r.diagnostic,
                flags=r.flags,
            )
        if isinstance(a, AABB) and isinstance(b, AABB):
            return aabb_aabb_toi(query)
    except (ArithmeticError, ValueError) as exc:
        return _result(query, ResultStatus.NUMERIC_FAILURE, diagnostic=f"backend exception: {exc}")
    return _result(
        query,
        ResultStatus.UNSUPPORTED,
        diagnostic=f"no registered elementary backend for {a.kind.value}-{b.kind.value}",
    )


def solve_scene(
    objects: Sequence[MovingObject],
    interval: TimeInterval,
    policy: CCDPolicy,
) -> tuple[list[CCDResult], list[BroadPhaseDecision]]:
    pairs, decisions = broad_phase(objects, interval, policy.minimum_separation)
    results: list[CCDResult] = []
    for i, j in pairs:
        results.append(
            dispatch(
                CCDQuery(
                    objects[i],
                    objects[j],
                    interval,
                    policy,
                    query_id=f"{objects[i].object_id}:{objects[j].object_id}",
                )
            )
        )
    return results, decisions


__all__ = [
    "AABB",
    "Bounds3",
    "BroadPhaseDecision",
    "CCDPolicy",
    "CCDQuery",
    "CCDResult",
    "CertificateClass",
    "LinearMotion",
    "MotionKind",
    "MovingObject",
    "Plane",
    "ResultStatus",
    "SeparationSample",
    "ShapeKind",
    "Sphere",
    "TimeInterval",
    "Vec3",
    "aabb_aabb_toi",
    "broad_phase",
    "conservative_advancement",
    "dispatch",
    "moving_sphere_static_sphere_oracle",
    "solve_scene",
    "sphere_plane_toi",
    "sphere_sphere_toi",
    "swept_bounds",
]
