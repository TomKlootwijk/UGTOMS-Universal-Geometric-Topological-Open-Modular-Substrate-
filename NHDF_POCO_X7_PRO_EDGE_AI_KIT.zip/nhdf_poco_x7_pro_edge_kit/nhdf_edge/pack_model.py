from __future__ import annotations

import argparse
import gc
import json
import re
import sys
import time
from pathlib import Path

import numpy as np

from .format import NHDFPackWriter
from .model_utils import iter_tensors, tensor_shapes_and_dtypes
from .policy import build_tensor_plans, load_profile, load_sensitivity


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Pack Hugging Face safetensors into NHDFPK01")
    p.add_argument("--model-dir", required=True, help="Directory containing config.json and safetensors shards")
    p.add_argument("--output", required=True, help="Output .nhdfpack file")
    p.add_argument("--profile", required=True, help="YAML packing profile")
    p.add_argument("--sensitivity", help="Optional JSON sensitivity scores")
    p.add_argument("--include-regex", help="Pack only matching tensor names (smoke testing)")
    p.add_argument("--limit-tensors", type=int, default=0, help="Stop after N tensors; 0 means all")
    p.add_argument("--overwrite", action="store_true")
    return p.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    model_dir = Path(args.model_dir)
    output = Path(args.output)
    if output.exists() and not args.overwrite:
        print(f"refusing to overwrite {output}; pass --overwrite", file=sys.stderr)
        return 2

    profile = load_profile(args.profile)
    sensitivity = load_sensitivity(args.sensitivity)
    shapes, dtypes = tensor_shapes_and_dtypes(model_dir)
    names = sorted(shapes)
    if args.include_regex:
        rx = re.compile(args.include_regex)
        names = [n for n in names if rx.search(n)]
    if args.limit_tensors:
        names = names[: args.limit_tensors]
    selected_shapes = {n: shapes[n] for n in names}
    plans = build_tensor_plans(selected_shapes, profile, sensitivity)

    model_id = profile.get("model", {}).get("id", model_dir.name)
    profile_name = profile.get("profile_name", Path(args.profile).stem)
    block_size = int(profile.get("quantization", {}).get("block_size", 512))
    gamma = float(profile.get("quantization", {}).get("gamma", 15.0))
    metadata = {
        "source_model_dir": str(model_dir),
        "profile": profile,
        "tensor_count_requested": len(names),
        "warning": "No model weights are redistributed by this package; this file is user-generated.",
    }

    started = time.time()
    with NHDFPackWriter(output, model_id=model_id, profile_name=profile_name, metadata=metadata) as writer:
        for idx, (name, tensor, source_dtype) in enumerate(iter_tensors(model_dir, names), start=1):
            plan = plans[name]
            t0 = time.time()
            arr = tensor.detach().cpu().float().numpy()
            if plan.codec == "fp16":
                desc = writer.add_fp16_tensor(name, arr, source_dtype=source_dtype)
            else:
                desc = writer.add_quantized_tensor(
                    name,
                    arr,
                    bits=plan.bits,
                    block_size=block_size,
                    gamma=gamma,
                    source_dtype=source_dtype,
                )
            elapsed = time.time() - t0
            print(
                json.dumps(
                    {
                        "tensor": name,
                        "index": idx,
                        "count": len(names),
                        "shape": list(arr.shape),
                        "codec": plan.codec,
                        "bits": plan.bits,
                        "data_mb": round(desc.data_nbytes / 1e6, 2),
                        "seconds": round(elapsed, 3),
                        "reason": plan.reason,
                    },
                    sort_keys=True,
                ),
                flush=True,
            )
            del arr, tensor
            gc.collect()

    total_s = time.time() - started
    print(json.dumps({"output": str(output), "file_gb": round(output.stat().st_size / 1e9, 3), "seconds": round(total_s, 1)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
