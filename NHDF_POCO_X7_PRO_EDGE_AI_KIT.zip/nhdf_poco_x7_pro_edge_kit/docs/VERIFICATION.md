# Verification status

Verified in the build container on 31 August 2026:

- `pytest`: **8 tests passed**, covering 2/3/4-bit packing, log-polar
  reconstruction, fixed pack records, odd-fault parity detection, the explicit
  even-fault parity blind spot, SHA-256 detection, the Qwen size estimator, and
  KV-cache arithmetic.
- `bash scripts/smoke_test.sh`: passed without network access. It regenerated
  the toy safetensors model, built and read a `.nhdfpack`, verified parity and
  SHA-256, and regenerated the balanced full-model estimate.
- Toy reconstruction MSE from that run:
  - attention Q projection: `2.6197855e-05`;
  - MLP up projection: `2.8182057e-04`;
  - FP16 layer norm: `0`.
- Full-model planning result: `4.962569569 GB` decimal, `4.621753 GiB`, and
  `2.687975` effective bits per parameter for the balanced profile.
- Python bytecode compilation and Bash syntax checks passed.
- The final PDF was rendered and visually inspected page by page; PDF preflight
  opened all 17 pages and reported no warnings.

Not verified in this environment:

- execution on a physical POCO X7 Pro;
- downloading or packing the full Qwen checkpoint;
- end-to-end distillation or LoRA recovery;
- measured quality, speed, power, temperature, or sustained bandwidth;
- compilation of the Vulkan probe/shaders, because this container does not have
  Vulkan SDK headers/libraries or a GLSL compiler;
- integration of the custom codec shader into a complete transformer runtime.

The official Q2_K llama.cpp path is included specifically to establish a real
phone baseline before any NHDF advantage is claimed.
