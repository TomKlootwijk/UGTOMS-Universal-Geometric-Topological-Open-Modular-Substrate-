import numpy as np

from nhdf_edge.bitpack import pack_pair_codes, unpack_pair_codes


def test_pair_code_roundtrip():
    rng = np.random.default_rng(1)
    for bits in (2, 3, 4):
        limit = 1 << (2 * bits)
        for n in (1, 2, 3, 4, 7, 16, 257):
            codes = rng.integers(0, limit, n, dtype=np.uint16)
            packed = pack_pair_codes(codes, bits)
            restored = unpack_pair_codes(packed, bits, n)
            np.testing.assert_array_equal(restored, codes.astype(np.uint8))
