from __future__ import annotations

import json
import math
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import yaml


_LAYER_RE = re.compile(r"(?:model\.)?layers\.(\d+)\.")


@dataclass(frozen=True)
class TensorPlan:
    name: str
    codec: str
    bits: int
    reason: str


def load_profile(path: str | Path) -> dict:
    with Path(path).open("r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
    if not isinstance(data, dict):
        raise ValueError("profile must be a YAML mapping")
    return data


def load_sensitivity(path: str | Path | None) -> dict[str, float]:
    if path is None:
        return {}
    with Path(path).open("r", encoding="utf-8") as f:
        data = json.load(f)
    if isinstance(data, dict) and "tensors" in data:
        data = data["tensors"]
    out: dict[str, float] = {}
    for name, value in data.items():
        if isinstance(value, dict):
            score = value.get("score_2_to_3", value.get("score", 0.0))
        else:
            score = value
        out[str(name)] = float(score)
    return out


def classify_tensor(name: str, shape: Iterable[int]) -> str:
    dims = list(shape)
    lname = name.lower()
    if len(dims) < 2 or any(tag in lname for tag in ("norm", ".bias", "rotary_emb", "inv_freq")):
        return "fp16"
    if "embed_tokens" in lname or lname.endswith("wte.weight"):
        return "embedding"
    if "lm_head" in lname:
        return "lm_head"
    if ".self_attn.q_proj" in lname or ".self_attn.o_proj" in lname:
        return "attn_qo"
    if ".self_attn.k_proj" in lname or ".self_attn.v_proj" in lname:
        return "attn_kv"
    if ".mlp.gate_proj" in lname:
        return "mlp_gate"
    if ".mlp.up_proj" in lname:
        return "mlp_up"
    if ".mlp.down_proj" in lname:
        return "mlp_down"
    return "other_matrix"


def _golden_spread(names: list[str], count: int) -> set[str]:
    """Select a deterministic, depth-spread subset without claiming optimality."""
    if count <= 0:
        return set()
    if count >= len(names):
        return set(names)
    phi = (1.0 + math.sqrt(5.0)) / 2.0
    ranked = sorted(
        names,
        key=lambda name: (
            ((int(_LAYER_RE.search(name).group(1)) if _LAYER_RE.search(name) else 0) / phi) % 1.0,
            name,
        ),
    )
    # Pin early/late tensors, then fill by golden-spread order.
    pinned = []
    by_layer = sorted(names, key=lambda n: (int(_LAYER_RE.search(n).group(1)) if _LAYER_RE.search(n) else 10**9, n))
    if by_layer:
        pinned.extend(by_layer[: min(3, count)])
        remaining = max(0, count - len(set(pinned)))
        if remaining:
            pinned.extend(by_layer[-min(3, remaining) :])
    selected = list(dict.fromkeys(pinned))
    for name in ranked:
        if len(selected) >= count:
            break
        if name not in selected:
            selected.append(name)
    return set(selected[:count])


def build_tensor_plans(
    tensor_shapes: dict[str, list[int]],
    profile: dict,
    sensitivity: dict[str, float] | None = None,
) -> dict[str, TensorPlan]:
    sensitivity = sensitivity or {}
    quant = profile.get("quantization", {})
    base_bits = quant.get("base_bits", {})
    mlp_low = int(quant.get("mlp_low_bits", 2))
    mlp_high = int(quant.get("mlp_high_bits", 3))
    high_fraction = float(quant.get("mlp_high_fraction", 0.25))

    classes = {name: classify_tensor(name, shape) for name, shape in tensor_shapes.items()}
    mlp_names = [name for name, cls in classes.items() if cls.startswith("mlp_")]
    high_count = int(round(len(mlp_names) * high_fraction))
    if sensitivity:
        high_mlp = set(sorted(mlp_names, key=lambda n: (sensitivity.get(n, float("-inf")), n), reverse=True)[:high_count])
        selection_reason = "activation/weight sensitivity budget"
    else:
        high_mlp = _golden_spread(sorted(mlp_names), high_count)
        selection_reason = "golden-spread fallback (no sensitivity file)"

    plans: dict[str, TensorPlan] = {}
    for name, cls in classes.items():
        if cls == "fp16":
            plans[name] = TensorPlan(name, "fp16", 16, "small/normal/bias tensor retained in FP16")
            continue
        if cls.startswith("mlp_"):
            bits = mlp_high if name in high_mlp else mlp_low
            reason = f"{cls}: {bits}-bit leaf selected by {selection_reason}"
            plans[name] = TensorPlan(name, "logpolar", bits, reason)
            continue
        bits = int(base_bits.get(cls, base_bits.get("other_matrix", 3)))
        if bits not in (2, 3, 4):
            raise ValueError(f"unsupported bits={bits} for {name}")
        plans[name] = TensorPlan(name, "logpolar", bits, f"{cls} profile")
    return plans
