from __future__ import annotations

import argparse
import json
import random
from pathlib import Path

import numpy as np

from .logpolar import decode_blocks, encode_blocks
from .model_utils import iter_tensors, tensor_shapes_and_dtypes
from .policy import classify_tensor, load_profile


def sample_weight_sensitivity(
    values: np.ndarray,
    *,
    block_size: int,
    gamma: float,
    sample_blocks: int,
    seed: int,
) -> dict[str, float]:
    flat = np.asarray(values, dtype=np.float32).reshape(-1)
    n_blocks = (flat.size + block_size - 1) // block_size
    rng = random.Random(seed)
    ids = list(range(n_blocks))
    if len(ids) > sample_blocks:
        ids = rng.sample(ids, sample_blocks)
    samples = []
    for block_id in ids:
        start = block_id * block_size
        block = flat[start : start + block_size]
        if block.size < block_size:
            block = np.pad(block, (0, block_size - block.size), mode="edge")
        samples.append(block)
    if not samples:
        return {"mse2": 0.0, "mse3": 0.0, "mse4": 0.0, "score_2_to_3": 0.0, "score_3_to_4": 0.0}
    sample = np.concatenate(samples)
    mse = {}
    denom = float(np.mean(sample.astype(np.float64) ** 2) + 1e-12)
    for bits in (2, 3, 4):
        enc = encode_blocks(sample, bits=bits, block_size=block_size, gamma=gamma)
        rec = decode_blocks(enc.records, bits=bits, block_size=block_size, gamma=gamma, original_size=sample.size)
        mse[bits] = float(np.mean((sample - rec) ** 2) / denom)
    return {
        "mse2": mse[2],
        "mse3": mse[3],
        "mse4": mse[4],
        "score_2_to_3": mse[2] - mse[3],
        "score_3_to_4": mse[3] - mse[4],
    }


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="Weight-only sensitivity calibration for NHDF mixed precision")
    p.add_argument("--model-dir", required=True)
    p.add_argument("--profile", required=True)
    p.add_argument("--output", required=True)
    p.add_argument("--sample-blocks", type=int, default=128)
    p.add_argument("--seed", type=int, default=17)
    p.add_argument("--include-regex")
    args = p.parse_args(argv)

    profile = load_profile(args.profile)
    block_size = int(profile.get("quantization", {}).get("block_size", 512))
    gamma = float(profile.get("quantization", {}).get("gamma", 15.0))
    shapes, _ = tensor_shapes_and_dtypes(args.model_dir)
    names = [n for n, shape in shapes.items() if classify_tensor(n, shape) != "fp16"]
    if args.include_regex:
        import re
        rx = re.compile(args.include_regex)
        names = [n for n in names if rx.search(n)]

    out = {"method": "weight-only normalized MSE; activation-aware calibration is preferred", "tensors": {}}
    for idx, (name, tensor, _) in enumerate(iter_tensors(args.model_dir, sorted(names)), start=1):
        arr = tensor.detach().cpu().float().numpy()
        stats = sample_weight_sensitivity(
            arr,
            block_size=block_size,
            gamma=gamma,
            sample_blocks=args.sample_blocks,
            seed=args.seed + idx,
        )
        out["tensors"][name] = stats
        print(json.dumps({"tensor": name, **stats}, sort_keys=True), flush=True)
    Path(args.output).write_text(json.dumps(out, indent=2, sort_keys=True), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
