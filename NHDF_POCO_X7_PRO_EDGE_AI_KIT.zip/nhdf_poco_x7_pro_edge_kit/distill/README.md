# Quantization-aware distillation and recovery

The phone is an inference target, not the training machine.  The recommended
sequence is:

1. Cache top-k teacher logits from `Qwen/Qwen2.5-14B-Instruct` on a capable
   workstation with `cache_teacher_topk.py`.
2. Run `nhdf-sensitivity` as a fast weight-only first pass.  For publication
   quality, replace it with activation-aware error measurements.
3. Use the selected mixed-precision profile to fake-quantize a student that is
   initialized from the same 14.7B checkpoint.  Train low-rank adapters against
   the cached teacher distributions with `train_lora_recovery.py`.
4. Merge the adapters into the recovered checkpoint and run `nhdf-pack`.
5. Evaluate against BF16, official Q2_K, and official Q3_K_M baselines.

This is *same-architecture knowledge distillation*: it recovers accuracy lost by
very low-bit packing while retaining all 48 transformer layers.  It is not a
claim that the original BF16 weights are losslessly compressed.

The scripts are intentionally conservative and will require a large-memory host
or CPU/NVMe offload.  They are templates for CODEX to adapt to the available
training hardware and dataset.
