from __future__ import annotations

import argparse
import json
from pathlib import Path

from .format import NHDFPackReader


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="Inspect and parity-check an NHDF pack")
    p.add_argument("pack")
    p.add_argument("--verify", action="store_true", help="Verify every tensor parity bitmap")
    p.add_argument(
        "--verify-hash",
        action="store_true",
        help="Also verify each tensor SHA-256 (slower, catches parity's even-fault blind spot)",
    )
    p.add_argument("--tensor", help="Decode one tensor and report simple statistics")
    args = p.parse_args(argv)

    with NHDFPackReader(args.pack) as reader:
        print(json.dumps(reader.summary(), indent=2, sort_keys=True))
        if args.verify or args.verify_hash:
            for name in reader.tensors:
                record = {"tensor": name}
                failed = False
                if args.verify:
                    ok, bad = reader.verify_tensor(name)
                    record.update({"parity_ok": ok, "first_bad_block": bad})
                    failed = failed or not ok
                if args.verify_hash:
                    hash_ok = reader.verify_tensor_hash(name)
                    record["sha256_ok"] = hash_ok
                    failed = failed or not hash_ok
                print(json.dumps(record))
                if failed:
                    return 1
        if args.tensor:
            arr = reader.read_tensor(args.tensor)
            print(
                json.dumps(
                    {
                        "tensor": args.tensor,
                        "shape": list(arr.shape),
                        "min": float(arr.min()),
                        "max": float(arr.max()),
                        "mean": float(arr.mean()),
                        "rms": float((arr.astype("float64") ** 2).mean() ** 0.5),
                    },
                    indent=2,
                )
            )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
