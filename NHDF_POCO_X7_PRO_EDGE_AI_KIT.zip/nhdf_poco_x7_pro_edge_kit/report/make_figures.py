from __future__ import annotations

import csv
import json
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "report" / "assets"
METRICS = ROOT / "metrics"
ASSETS.mkdir(parents=True, exist_ok=True)

NAVY = "#173b57"
TEAL = "#00a2a5"
GOLD = "#d49a2a"
LIGHT = "#eaf1f4"
DARK = "#263238"
RED = "#b34d4d"

plt.rcParams.update({"font.size": 10, "font.family": "DejaVu Sans"})

# 1. Architecture diagram
fig, ax = plt.subplots(figsize=(12, 6.4))
ax.set_xlim(0, 12)
ax.set_ylim(0, 7)
ax.axis("off")

def box(x, y, w, h, title, body, fc=LIGHT, ec=NAVY):
    p = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.08", fc=fc, ec=ec, lw=1.5)
    ax.add_patch(p)
    ax.text(x+w/2, y+h-0.28, title, ha="center", va="top", color=NAVY, weight="bold", fontsize=10)
    ax.text(x+w/2, y+h/2-0.1, body, ha="center", va="center", color=DARK, fontsize=8.7, wrap=True)
    return p

def arrow(x1,y1,x2,y2, color=TEAL, style="-|>"):
    ax.add_patch(FancyArrowPatch((x1,y1),(x2,y2),arrowstyle=style,mutation_scale=13,lw=1.7,color=color))

box(0.25,4.9,2.0,1.35,"Teacher","Qwen2.5-14B-Instruct\nBF16, 14.7B parameters",fc="#f7f3e8",ec=GOLD)
box(2.65,4.9,2.05,1.35,"Calibration","Teacher top-k logits\nactivation / weight sensitivity")
box(5.1,4.9,2.05,1.35,"Recovery","Static NHDF fake quant\nLoRA distillation / QAT")
box(7.55,4.9,2.05,1.35,"NHDF packer","ELP -> B0 -> P -> RBST\n2/3/4-bit tensor leaves")
box(10.0,4.9,1.75,1.35,"Artifact","~4.96 GB target\nread-only .nhdfpack",fc="#e6f6f4",ec=TEAL)
for a,b in [(2.25,2.65),(4.7,5.1),(7.15,7.55),(9.6,10.0)]: arrow(a,5.575,b,5.575)

box(0.55,2.35,3.0,1.45,"POCO X7 Pro shared-memory substrate","Dimensity 8400-Ultra\n12 GB LPDDR5X + UFS 4.0\nCPU / GPU share bandwidth",fc="#eef5fb")
box(4.15,2.35,2.25,1.45,"Mali-G720 MC7","Vulkan prefill and fused\nlog-polar dequant + GEMV/GEMM",fc="#e6f6f4",ec=TEAL)
box(6.85,2.35,2.1,1.45,"Cortex-A725 CPU","sampling, tokenizer, control;\noptional decode fallback")
box(9.4,2.35,2.0,1.45,"Bounded runtime","Q8 KV cache; 2K default,\n4K recommended maximum",fc="#f7f3e8",ec=GOLD)
arrow(10.85,4.9,10.85,3.82)
arrow(3.55,3.08,4.15,3.08)
arrow(6.4,3.08,6.85,3.08)
arrow(8.95,3.08,9.4,3.08)

box(2.2,0.35,2.3,1.15,"Observation (Pi)","tokens, logits, latency,\nquality and thermal telemetry")
box(5.05,0.35,2.35,1.15,"Feedback (U)","calibration residuals update\nprecision plan / LoRA adapters")
box(7.95,0.35,2.2,1.15,"Safe mode","freeze new work, reload block,\nfall back after parity-rate alarm",fc="#f9ecec",ec=RED)
arrow(10.4,2.35,9.55,1.5)
arrow(4.5,0.925,5.05,0.925)
arrow(7.4,0.925,7.95,0.925)
# Route the closed feedback path through the clear gap between the Mali and CPU boxes.
ax.plot([6.225, 6.62, 6.62, 6.20], [1.50, 1.82, 4.42, 4.42], color=GOLD, lw=1.7)
arrow(6.20,4.42,6.20,4.9,color=GOLD,style="-|>")
ax.text(6.78,4.40,"closed training / calibration loop",fontsize=7.4,color=GOLD,va="center",ha="left")
ax.text(0.25,6.68,"NHDF-MP14 mobile architecture",fontsize=18,weight="bold",color=NAVY)
ax.text(0.25,6.35,"Source operator semantics preserved; AI-specific packing and mobile runtime are engineering extensions.",fontsize=10.5,color=DARK)
fig.tight_layout()
fig.savefig(ASSETS / "architecture.png", dpi=220, bbox_inches="tight")
plt.close(fig)

# 2. Shared memory diagram
fig, ax = plt.subplots(figsize=(10.5, 5.4))
ax.set_xlim(0,10.5); ax.set_ylim(0,5.4); ax.axis('off')
ax.add_patch(FancyBboxPatch((2.0,1.4),6.5,2.25,boxstyle="round,pad=.04,rounding_size=.12",fc="#eef5fb",ec=NAVY,lw=2))
ax.text(5.25,3.37,"LPDDR5X shared physical memory",ha='center',va='center',fontsize=16,weight='bold',color=NAVY)
ax.text(5.25,3.0,"one bandwidth pool - not 12 GB of dedicated GPU VRAM",ha='center',va='center',fontsize=10,color=DARK)
ax.add_patch(Rectangle((2.35,1.78),2.2,.75,fc="#e6f6f4",ec=TEAL,lw=1.3)); ax.text(3.45,2.15,"NHDF weight arenas",ha='center',va='center',weight='bold')
ax.add_patch(Rectangle((4.65,1.78),1.55,.75,fc="#f7f3e8",ec=GOLD,lw=1.3)); ax.text(5.425,2.15,"KV cache",ha='center',va='center',weight='bold')
ax.add_patch(Rectangle((6.3,1.78),1.85,.75,fc="#f4f4f4",ec=NAVY,lw=1.3)); ax.text(7.225,2.15,"activation ring",ha='center',va='center',weight='bold')
for x,title,body in [(0.35,"Cortex-A725 CPU","tokenizer, sampling,\ncontrol and fallback"),(4.15,"Mali-G720 MC7","Vulkan compute;\nshared-memory reads"),(8.75,"NPU 880 (optional)","closed/toolkit path;\nnot required")]:
    ax.add_patch(FancyBboxPatch((x,4.15),1.45,0.9,boxstyle="round,pad=.03",fc=LIGHT,ec=NAVY,lw=1.3))
    ax.text(x+.725,4.78,title,ha='center',va='center',weight='bold',fontsize=9)
    ax.text(x+.725,4.42,body,ha='center',va='center',fontsize=7.6)
arrowprops=dict(arrowstyle="<->",mutation_scale=13,lw=1.5,color=TEAL)
ax.add_patch(FancyArrowPatch((1.08,4.15),(2.75,3.65),**arrowprops))
ax.add_patch(FancyArrowPatch((4.88,4.15),(5.25,3.65),**arrowprops))
ax.add_patch(FancyArrowPatch((9.48,4.15),(7.75,3.65),**arrowprops))
ax.add_patch(FancyBboxPatch((4.15,.25),2.2,.65,boxstyle="round,pad=.03",fc="#fafafa",ec=DARK,lw=1.2))
ax.text(5.25,.575,"UFS 4.0 - load once; no per-token reads",ha='center',va='center',fontsize=9,weight='bold')
ax.add_patch(FancyArrowPatch((5.25,.9),(5.25,1.4),arrowstyle="-|>",mutation_scale=13,lw=1.5,color=GOLD))
ax.text(.25,5.2,"How the Mali GPU and LPDDR5X are 'linked'",fontsize=17,weight='bold',color=NAVY)
fig.tight_layout()
fig.savefig(ASSETS / "shared_memory.png", dpi=220, bbox_inches="tight")
plt.close(fig)

# 3. Model size comparison
rows=[]
with (METRICS/'model_size_comparison.csv').open() as f:
    for r in csv.DictReader(f): rows.append(r)
labels=[r['variant'].replace(' official GGUF','').replace(' target','') for r in rows]
sizes=[float(r['size_gb_decimal']) for r in rows]
fig, ax=plt.subplots(figsize=(10.5,6.5))
y=np.arange(len(labels))
colors=[GOLD if 'BF16' in l else (TEAL if 'NHDF' in l else NAVY) for l in labels]
ax.barh(y,sizes,color=colors,alpha=.9)
ax.set_yticks(y,labels)
ax.invert_yaxis(); ax.set_xlabel('Model weight file size (GB, decimal)')
ax.set_title('Qwen2.5-14B weight-size envelope',weight='bold',color=NAVY,fontsize=16)
ax.axvline(7.0,color=RED,ls='--',lw=1.2)
ax.text(7.08,len(labels)-.35,'rough process-weight ceiling\ninside a 12 GB phone',color=RED,fontsize=8.5,va='bottom')
for yi,s in zip(y,sizes): ax.text(s+.15,yi,f'{s:.2f}',va='center',fontsize=8.5)
ax.grid(axis='x',alpha=.22)
fig.tight_layout(); fig.savefig(ASSETS/'model_sizes.png',dpi=220,bbox_inches='tight'); plt.close(fig)

# 4. Memory budget
mem=[]
with (METRICS/'memory_budget_balanced.csv').open() as f:
    for r in csv.DictReader(f):
        if r['region']!='TOTAL': mem.append((r['region'],float(r['gib'])))
fig, ax=plt.subplots(figsize=(10.5,3.6))
left=0
palette=[TEAL,NAVY,GOLD,"#7b9acc","#8bb174","#b58db6"]
for (label,val),c in zip(mem,palette):
    ax.barh([0],[val],left=left,label=f'{label} ({val:.2f} GiB)',color=c)
    if val>.2: ax.text(left+val/2,0,f'{val:.2f}',ha='center',va='center',fontsize=8,color='white' if c in [NAVY,TEAL] else DARK,weight='bold')
    left+=val
ax.axvline(7.25,color=RED,ls='--',lw=1.4,label='hard-abort target 7.25 GiB')
ax.set_xlim(0,8); ax.set_yticks([]); ax.set_xlabel('Target process resident memory (GiB)')
ax.set_title('Balanced NHDF-MP2.75 runtime memory budget at 4K Q8 KV',weight='bold',color=NAVY,fontsize=15)
ax.legend(loc='upper center',bbox_to_anchor=(.5,-.25),ncol=2,fontsize=8,frameon=False)
fig.tight_layout(); fig.savefig(ASSETS/'memory_budget.png',dpi=220,bbox_inches='tight'); plt.close(fig)

# 5. Decode roofline
balanced=json.loads((METRICS/'nhdf_mp275_estimate.json').read_text())
fig,ax=plt.subplots(figsize=(9.5,5.7))
bws=np.linspace(20,60,100)
for name,size,ls in [('NHDF-MP2.75',balanced['estimated_file_gb_decimal'],'-'),('Official Q2_K',5.77,'--')]:
    for eff in (.45,.55):
        ax.plot(bws,bws*eff/size,ls=ls,lw=2,label=f'{name}, efficiency {eff:.0%}')
ax.axvspan(25,55,color=LIGHT,alpha=.5)
ax.set_xlabel('Measured sustained model-read bandwidth (GB/s)')
ax.set_ylabel('Memory-bound decode estimate (tokens/s)')
ax.set_title('Decode roofline - measure bandwidth on the actual phone',weight='bold',color=NAVY,fontsize=15)
ax.grid(alpha=.25); ax.legend(fontsize=8)
fig.tight_layout(); fig.savefig(ASSETS/'decode_roofline.png',dpi=220,bbox_inches='tight'); plt.close(fig)

# 6. Operator mapping diagram
fig,ax=plt.subplots(figsize=(11,3.4)); ax.set_xlim(0,11); ax.set_ylim(0,3.4); ax.axis('off')
ops=[('ELP','pair residuals\nlog-polar encoded'),('B0','local anchor +\nreconstruction zero-set'),('P','one-bit block\nparity event'),('RBST','sensitivity tree\nassigns 2/3/4 bits'),('K T→','forward layer order\n+ generation tags'),('Scone','fused decode and\nmatmul sweep'),('Pi','logits/tokens +\ntelemetry'),('U','re-plan / LoRA\nrecovery feedback')]
xs=np.linspace(.15,9.65,len(ops))
for i,(op,body) in enumerate(ops):
    ax.add_patch(FancyBboxPatch((xs[i],1.05),1.15,1.25,boxstyle='round,pad=.02',fc=LIGHT if i not in (0,7) else '#e6f6f4',ec=TEAL if i in (0,7) else NAVY,lw=1.3))
    ax.text(xs[i]+.575,2.05,op,ha='center',va='center',weight='bold',color=NAVY,fontsize=9)
    ax.text(xs[i]+.575,1.48,body,ha='center',va='center',fontsize=7.3)
    if i<len(ops)-1: ax.add_patch(FancyArrowPatch((xs[i]+1.15,1.675),(xs[i+1],1.675),arrowstyle='-|>',mutation_scale=11,lw=1.2,color=TEAL))
ax.add_patch(FancyArrowPatch((10.25,1.05),(.7,.85),connectionstyle='arc3,rad=-.25',arrowstyle='-|>',mutation_scale=12,lw=1.4,color=GOLD))
ax.text(5.5,.2,'The feedback arrow is normative. The AI meanings are adapter-specific and must be benchmarked.',ha='center',fontsize=9,color=DARK)
ax.text(.15,3.05,'NHDF formal operator chain mapped to the mobile LLM adapter',fontsize=16,weight='bold',color=NAVY)
fig.tight_layout(); fig.savefig(ASSETS/'operator_mapping.png',dpi=220,bbox_inches='tight'); plt.close(fig)
