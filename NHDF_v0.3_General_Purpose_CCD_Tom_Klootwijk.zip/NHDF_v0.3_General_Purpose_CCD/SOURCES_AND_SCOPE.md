# Sources and scope boundary

The PDF is based on three user-supplied source documents:

1. the original 30-page prompt-chain transcript;
2. NHDF Formal Specification Version 0.1;
3. the 40-page IJburg-to-Hoofddorp commute transcript that introduced the literal CCD discussion.

Those documents support the NHDF vocabulary, local-zero-set formalization, log-polar metric motivation, operator-order discussion, and the initial intuition that an SDF gap plus kinematics can prevent tunneling under conditions.

They do **not** supply a complete general-purpose CCD algorithm. Version 0.3 therefore marks the broad phase, shape/motion dispatch, convex and mesh feature algorithms, interval/inclusion methods, deformable/self-contact handling, simultaneous contacts, and event-driven response as an extension informed by the primary CCD research references listed in the PDF.

No claim is made that the source transcripts are experimental proof, that the elementary scaffold implements every Version 0.3 backend, or that any named police, public institution, employer, location, or third party reviewed or endorsed the work.
