from __future__ import annotations

import numpy as np


def packed_nbytes(n_codes: int, bits_per_code: int) -> int:
    if bits_per_code not in (4, 6, 8):
        raise ValueError("bits_per_code must be 4, 6, or 8")
    return (n_codes * bits_per_code + 7) // 8


def pack_pair_codes(codes: np.ndarray, weight_bits: int) -> np.ndarray:
    """Pack one code per two weights.

    Each code contains a radial index and an angular index.  Both indices use
    ``weight_bits`` bits, so a code consumes 2*weight_bits bits and the average
    payload is exactly ``weight_bits`` bits per weight.
    """
    codes = np.asarray(codes, dtype=np.uint16).reshape(-1)
    max_code = (1 << (2 * weight_bits)) - 1
    if codes.size and int(codes.max()) > max_code:
        raise ValueError("code exceeds bit width")

    if weight_bits == 2:
        # Two 4-bit pair codes per byte.
        padded = np.zeros((codes.size + 1) // 2 * 2, dtype=np.uint8)
        padded[: codes.size] = codes.astype(np.uint8)
        out = padded[0::2] | (padded[1::2] << 4)
        return out

    if weight_bits == 3:
        # Four 6-bit pair codes in three bytes.
        n_groups = (codes.size + 3) // 4
        padded = np.zeros(n_groups * 4, dtype=np.uint16)
        padded[: codes.size] = codes
        c0, c1, c2, c3 = (padded[i::4] for i in range(4))
        out = np.empty(n_groups * 3, dtype=np.uint8)
        out[0::3] = (c0 | ((c1 & 0x03) << 6)).astype(np.uint8)
        out[1::3] = ((c1 >> 2) | ((c2 & 0x0F) << 4)).astype(np.uint8)
        out[2::3] = ((c2 >> 4) | (c3 << 2)).astype(np.uint8)
        return out

    if weight_bits == 4:
        return codes.astype(np.uint8)

    raise ValueError("weight_bits must be 2, 3, or 4")


def unpack_pair_codes(
    packed: np.ndarray | bytes | bytearray,
    weight_bits: int,
    n_codes: int,
) -> np.ndarray:
    data = np.frombuffer(packed, dtype=np.uint8) if not isinstance(packed, np.ndarray) else packed.astype(np.uint8, copy=False).reshape(-1)

    if weight_bits == 2:
        out = np.empty(data.size * 2, dtype=np.uint8)
        out[0::2] = data & 0x0F
        out[1::2] = data >> 4
        return out[:n_codes]

    if weight_bits == 3:
        if data.size % 3:
            raise ValueError("6-bit stream length must be a multiple of 3 bytes")
        b0, b1, b2 = (data[i::3].astype(np.uint16) for i in range(3))
        out = np.empty((data.size // 3) * 4, dtype=np.uint8)
        out[0::4] = (b0 & 0x3F).astype(np.uint8)
        out[1::4] = (((b0 >> 6) & 0x03) | ((b1 & 0x0F) << 2)).astype(np.uint8)
        out[2::4] = (((b1 >> 4) & 0x0F) | ((b2 & 0x03) << 4)).astype(np.uint8)
        out[3::4] = (b2 >> 2).astype(np.uint8)
        return out[:n_codes]

    if weight_bits == 4:
        return data[:n_codes].copy()

    raise ValueError("weight_bits must be 2, 3, or 4")


_POPCOUNT8 = np.array([int(i).bit_count() for i in range(256)], dtype=np.uint8)


def parity_rows(byte_rows: np.ndarray) -> np.ndarray:
    """Return XOR parity for each row of a uint8 matrix."""
    rows = np.asarray(byte_rows, dtype=np.uint8)
    if rows.ndim != 2:
        raise ValueError("byte_rows must be 2-D")
    return (_POPCOUNT8[rows].sum(axis=1, dtype=np.uint32) & 1).astype(np.uint8)


def pack_parity_bits(bits: np.ndarray) -> bytes:
    bits = np.asarray(bits, dtype=np.uint8).reshape(-1)
    return np.packbits(bits, bitorder="little").tobytes()


def unpack_parity_bits(data: bytes, count: int) -> np.ndarray:
    if count == 0:
        return np.empty(0, dtype=np.uint8)
    bits = np.unpackbits(np.frombuffer(data, dtype=np.uint8), bitorder="little")
    return bits[:count].astype(np.uint8, copy=False)
