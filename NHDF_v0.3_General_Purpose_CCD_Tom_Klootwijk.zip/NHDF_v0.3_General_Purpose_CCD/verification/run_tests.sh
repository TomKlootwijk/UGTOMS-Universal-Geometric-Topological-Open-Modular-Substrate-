#!/usr/bin/env sh
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
REF="$HERE/../reference"
cd "$REF"
python3 -m py_compile nhdf_ccd_reference.py test_nhdf_ccd_reference.py
python3 -m unittest -v test_nhdf_ccd_reference.py
