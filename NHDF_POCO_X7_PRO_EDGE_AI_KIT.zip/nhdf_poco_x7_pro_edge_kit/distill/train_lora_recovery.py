#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from peft import LoraConfig, get_peft_model
from transformers import AutoModelForCausalLM

from nhdf_edge.logpolar import decode_blocks, encode_blocks
from nhdf_edge.policy import build_tensor_plans, load_profile, load_sensitivity


def fake_quant_tensor(t: torch.Tensor, bits: int, block_size: int, gamma: float) -> torch.Tensor:
    arr = t.detach().cpu().float().numpy()
    enc = encode_blocks(arr.reshape(-1), bits=bits, block_size=block_size, gamma=gamma)
    rec = decode_blocks(
        enc.records,
        bits=bits,
        block_size=block_size,
        gamma=gamma,
        original_size=arr.size,
    ).reshape(arr.shape)
    return torch.from_numpy(rec).to(dtype=t.dtype, device=t.device)


def apply_static_nhdf_fake_quant(model: torch.nn.Module, profile_path: str, sensitivity_path: str | None) -> None:
    profile = load_profile(profile_path)
    sensitivity = load_sensitivity(sensitivity_path)
    named = dict(model.named_parameters())
    shapes = {name: list(param.shape) for name, param in named.items()}
    plans = build_tensor_plans(shapes, profile, sensitivity)
    block_size = int(profile["quantization"].get("block_size", 512))
    gamma = float(profile["quantization"].get("gamma", 15.0))
    with torch.no_grad():
        for i, (name, param) in enumerate(named.items(), start=1):
            plan = plans[name]
            if plan.codec != "logpolar":
                continue
            param.copy_(fake_quant_tensor(param, plan.bits, block_size, gamma))
            print(json.dumps({"fake_quantized": name, "bits": plan.bits, "index": i}), flush=True)


def sparse_topk_kl(student_logits: torch.Tensor, indices: torch.Tensor, teacher_values: torch.Tensor, temperature: float) -> torch.Tensor:
    # Both distributions are renormalized over the cached top-k support.  This is
    # an approximation to full-vocabulary KL, chosen to make the cache tractable.
    selected = torch.gather(student_logits, dim=-1, index=indices.long())
    t_logp = F.log_softmax(teacher_values.float() / temperature, dim=-1)
    s_logp = F.log_softmax(selected.float() / temperature, dim=-1)
    t_p = t_logp.exp()
    return F.kl_div(s_logp, t_p, reduction="batchmean", log_target=False) * (temperature**2)


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--model", default="Qwen/Qwen2.5-14B-Instruct")
    p.add_argument("--teacher-cache", required=True)
    p.add_argument("--profile", required=True)
    p.add_argument("--sensitivity")
    p.add_argument("--output-dir", required=True)
    p.add_argument("--steps", type=int, default=200)
    p.add_argument("--lr", type=float, default=2e-5)
    p.add_argument("--temperature", type=float, default=2.0)
    p.add_argument("--lora-r", type=int, default=16)
    p.add_argument("--ce-weight", type=float, default=0.15)
    args = p.parse_args()

    model = AutoModelForCausalLM.from_pretrained(
        args.model,
        torch_dtype=torch.bfloat16,
        device_map="auto",
        low_cpu_mem_usage=True,
    )
    model.config.use_cache = False
    apply_static_nhdf_fake_quant(model, args.profile, args.sensitivity)

    lora = LoraConfig(
        r=args.lora_r,
        lora_alpha=2 * args.lora_r,
        lora_dropout=0.05,
        bias="none",
        task_type="CAUSAL_LM",
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
    )
    model = get_peft_model(model, lora)
    model.train()
    trainable = [p for p in model.parameters() if p.requires_grad]
    optimizer = torch.optim.AdamW(trainable, lr=args.lr)

    cache = torch.load(args.teacher_cache, map_location="cpu")
    records = cache["records"]
    if not records:
        raise ValueError("teacher cache is empty")

    for step in range(args.steps):
        rec = records[step % len(records)]
        device = next(model.parameters()).device
        input_ids = rec["input_ids"].long().unsqueeze(0).to(device)
        attention_mask = rec["attention_mask"].long().unsqueeze(0).to(device)
        out = model(input_ids=input_ids, attention_mask=attention_mask)
        student = out.logits[:, :-1]
        indices = rec["teacher_topk_indices"].unsqueeze(0).to(device)
        teacher_values = rec["teacher_topk_logits"].unsqueeze(0).to(device)
        kl = sparse_topk_kl(student, indices, teacher_values, args.temperature)
        labels = input_ids[:, 1:]
        ce = F.cross_entropy(student.reshape(-1, student.shape[-1]), labels.reshape(-1))
        loss = kl + args.ce_weight * ce
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(trainable, 1.0)
        optimizer.step()
        print(json.dumps({"step": step, "loss": float(loss), "kl": float(kl), "ce": float(ce)}), flush=True)

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    model.save_pretrained(out_dir)
    (out_dir / "recovery_recipe.json").write_text(
        json.dumps(vars(args), indent=2, sort_keys=True), encoding="utf-8"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
