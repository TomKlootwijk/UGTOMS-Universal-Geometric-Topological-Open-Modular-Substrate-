from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from safetensors.numpy import save_file

from .format import NHDFPackReader, NHDFPackWriter


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="Create and verify a tiny NHDF pack")
    p.add_argument("--out-dir", default="samples")
    args = p.parse_args(argv)
    root = Path(args.out_dir)
    root.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(7)
    tensors = {
        "model.layers.0.self_attn.q_proj.weight": rng.normal(0, 0.02, (64, 64)).astype(np.float32),
        "model.layers.0.mlp.up_proj.weight": rng.normal(0, 0.03, (96, 64)).astype(np.float32),
        "model.layers.0.input_layernorm.weight": np.ones(64, dtype=np.float32),
    }
    safe_path = root / "toy_qwenish.safetensors"
    pack_path = root / "toy_qwenish.nhdfpack"
    save_file(tensors, str(safe_path))
    with NHDFPackWriter(pack_path, model_id="toy/qwenish", profile_name="toy") as writer:
        writer.add_quantized_tensor(next(iter(tensors)), tensors[next(iter(tensors))], bits=3)
        writer.add_quantized_tensor("model.layers.0.mlp.up_proj.weight", tensors["model.layers.0.mlp.up_proj.weight"], bits=2)
        writer.add_fp16_tensor("model.layers.0.input_layernorm.weight", tensors["model.layers.0.input_layernorm.weight"])
    with NHDFPackReader(pack_path) as reader:
        for name in tensors:
            restored = reader.read_tensor(name)
            mse = float(np.mean((restored - tensors[name]) ** 2))
            print(f"{name}: shape={restored.shape}, mse={mse:.8g}")
        print(reader.summary())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
