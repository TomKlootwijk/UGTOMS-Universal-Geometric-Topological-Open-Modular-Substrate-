#!/usr/bin/env bash
set -euo pipefail

: "${ANDROID_NDK_HOME:?Set ANDROID_NDK_HOME to the Android NDK root}"
LLAMA_CPP_REF="${LLAMA_CPP_REF:-b10711}"
ROOT="${1:-$PWD/build/llama.cpp}"

if [[ ! -d "$ROOT/.git" ]]; then
  git clone --depth 1 --branch "$LLAMA_CPP_REF" https://github.com/ggml-org/llama.cpp.git "$ROOT"
else
  git -C "$ROOT" fetch --tags origin
  git -C "$ROOT" checkout "$LLAMA_CPP_REF"
fi

cmake -S "$ROOT" -B "$ROOT/build-android" -G Ninja \
  -DCMAKE_TOOLCHAIN_FILE="$ANDROID_NDK_HOME/build/cmake/android.toolchain.cmake" \
  -DANDROID_ABI=arm64-v8a \
  -DANDROID_PLATFORM=android-29 \
  -DCMAKE_BUILD_TYPE=Release \
  -DGGML_VULKAN=ON \
  -DGGML_OPENMP=OFF \
  -DLLAMA_CURL=OFF \
  -DLLAMA_BUILD_TESTS=OFF \
  -DLLAMA_BUILD_EXAMPLES=ON

cmake --build "$ROOT/build-android" -j --target llama-cli llama-bench
printf 'Built binaries under %s\n' "$ROOT/build-android/bin"
