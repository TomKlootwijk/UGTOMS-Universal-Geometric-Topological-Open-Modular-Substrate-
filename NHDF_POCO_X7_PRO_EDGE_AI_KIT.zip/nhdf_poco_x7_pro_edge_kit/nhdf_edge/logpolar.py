from __future__ import annotations

from dataclasses import dataclass
from typing import Iterator

import numpy as np

from .bitpack import pack_pair_codes, packed_nbytes, parity_rows, unpack_pair_codes


@dataclass(frozen=True)
class EncodedChunk:
    records: bytes
    parity: np.ndarray
    block_count: int
    record_bytes: int
    payload_bytes: int


def _validate(block_size: int, bits: int, gamma: float) -> None:
    if block_size <= 0 or block_size % 2:
        raise ValueError("block_size must be a positive even integer")
    if bits not in (2, 3, 4):
        raise ValueError("bits must be 2, 3, or 4")
    if gamma <= 0:
        raise ValueError("gamma must be > 0")


def encode_blocks(
    values: np.ndarray,
    *,
    bits: int,
    block_size: int = 512,
    gamma: float = 15.0,
) -> EncodedChunk:
    """Encode a one-dimensional float array into fixed-size NHDF records.

    Record layout per block:
      - FP16 local anchor/mean (2 bytes)
      - FP16 radial scale (2 bytes)
      - packed log-polar pair codes

    The local validity field can be written as
    ``F_i(z) = z - (mean_i + decode(code_i, scale_i))``.  Decoded states lie
    on its local zero set by construction.
    """
    _validate(block_size, bits, gamma)
    flat = np.asarray(values, dtype=np.float32).reshape(-1)
    original_size = flat.size
    n_blocks = (original_size + block_size - 1) // block_size
    if n_blocks == 0:
        payload_bytes = block_size * bits // 8
        return EncodedChunk(b"", np.empty(0, dtype=np.uint8), 0, 4 + payload_bytes, payload_bytes)

    padded = np.empty(n_blocks * block_size, dtype=np.float32)
    padded[:original_size] = flat
    if original_size < padded.size:
        # Padding with the last value keeps the final local anchor well behaved.
        fill = float(flat[-1]) if original_size else 0.0
        padded[original_size:] = fill

    blocks = padded.reshape(n_blocks, block_size)
    means = blocks.mean(axis=1, dtype=np.float32)
    centered = blocks - means[:, None]
    pairs = centered.reshape(n_blocks, block_size // 2, 2)
    radius = np.sqrt(np.square(pairs[..., 0]) + np.square(pairs[..., 1]), dtype=np.float32)
    scales = radius.max(axis=1)
    safe_scale = np.where(scales > np.finfo(np.float16).tiny, scales, 1.0).astype(np.float32)

    levels = 1 << bits
    rho_norm = np.log1p(gamma * radius / safe_scale[:, None]) / np.log1p(gamma)
    q_r = np.rint(rho_norm * (levels - 1)).clip(0, levels - 1).astype(np.uint16)

    theta = np.mod(np.arctan2(pairs[..., 1], pairs[..., 0]), 2.0 * np.pi)
    q_t = np.floor(theta * levels / (2.0 * np.pi) + 0.5).astype(np.uint16) % levels
    q_t = np.where(radius == 0.0, 0, q_t).astype(np.uint16)

    codes = q_r | (q_t << bits)
    n_codes = block_size // 2
    payload_bytes = packed_nbytes(n_codes, 2 * bits)
    record_bytes = 4 + payload_bytes
    records = np.empty((n_blocks, record_bytes), dtype=np.uint8)
    records[:, 0:2] = means.astype("<f2").view(np.uint8).reshape(n_blocks, 2)
    records[:, 2:4] = scales.astype("<f2").view(np.uint8).reshape(n_blocks, 2)

    for i in range(n_blocks):
        packed = pack_pair_codes(codes[i], bits)
        if packed.size != payload_bytes:
            raise AssertionError("unexpected packed payload length")
        records[i, 4:] = packed

    parity = parity_rows(records)
    return EncodedChunk(records.tobytes(), parity, n_blocks, record_bytes, payload_bytes)


def decode_blocks(
    records: bytes | np.ndarray,
    *,
    bits: int,
    block_size: int = 512,
    gamma: float = 15.0,
    original_size: int | None = None,
) -> np.ndarray:
    _validate(block_size, bits, gamma)
    n_codes = block_size // 2
    payload_bytes = packed_nbytes(n_codes, 2 * bits)
    record_bytes = 4 + payload_bytes
    raw = np.frombuffer(records, dtype=np.uint8) if not isinstance(records, np.ndarray) else np.asarray(records, dtype=np.uint8).reshape(-1)
    if raw.size % record_bytes:
        raise ValueError("record stream has a truncated block")
    n_blocks = raw.size // record_bytes
    rows = raw.reshape(n_blocks, record_bytes)
    means = rows[:, 0:2].copy().reshape(-1).view("<f2").astype(np.float32)
    scales = rows[:, 2:4].copy().reshape(-1).view("<f2").astype(np.float32)

    levels = 1 << bits
    radial_lut = np.expm1(np.arange(levels, dtype=np.float32) / (levels - 1) * np.log1p(gamma)) / gamma
    angle_lut = np.arange(levels, dtype=np.float32) * (2.0 * np.pi / levels)

    out = np.empty((n_blocks, block_size), dtype=np.float32)
    for i in range(n_blocks):
        codes = unpack_pair_codes(rows[i, 4:], bits, n_codes).astype(np.uint16)
        q_r = codes & (levels - 1)
        q_t = codes >> bits
        radius = scales[i] * radial_lut[q_r]
        theta = angle_lut[q_t]
        pairs = np.empty((n_codes, 2), dtype=np.float32)
        pairs[:, 0] = radius * np.cos(theta)
        pairs[:, 1] = radius * np.sin(theta)
        out[i] = means[i] + pairs.reshape(-1)

    flat = out.reshape(-1)
    return flat if original_size is None else flat[:original_size]


def iter_encoded_chunks(
    values: np.ndarray,
    *,
    bits: int,
    block_size: int = 512,
    gamma: float = 15.0,
    blocks_per_chunk: int = 4096,
) -> Iterator[EncodedChunk]:
    """Encode large arrays without retaining the full packed tensor in RAM."""
    _validate(block_size, bits, gamma)
    flat = np.asarray(values, dtype=np.float32).reshape(-1)
    stride = block_size * blocks_per_chunk
    for start in range(0, flat.size, stride):
        yield encode_blocks(flat[start : start + stride], bits=bits, block_size=block_size, gamma=gamma)
