from __future__ import annotations

import json
from pathlib import Path
from typing import Iterator

from safetensors import safe_open


def discover_safetensors(model_dir: str | Path) -> list[Path]:
    root = Path(model_dir)
    files = sorted(root.glob("*.safetensors"))
    if not files:
        raise FileNotFoundError(f"no .safetensors files found in {root}")
    return files


def tensor_index(model_dir: str | Path) -> dict[str, Path]:
    root = Path(model_dir)
    index_file = root / "model.safetensors.index.json"
    if index_file.exists():
        data = json.loads(index_file.read_text(encoding="utf-8"))
        weight_map = data.get("weight_map", {})
        return {name: root / filename for name, filename in weight_map.items()}

    index: dict[str, Path] = {}
    for path in discover_safetensors(root):
        with safe_open(path, framework="pt", device="cpu") as f:
            for key in f.keys():
                if key in index:
                    raise ValueError(f"duplicate tensor key {key}")
                index[key] = path
    return index


def tensor_shapes_and_dtypes(model_dir: str | Path) -> tuple[dict[str, list[int]], dict[str, str]]:
    index = tensor_index(model_dir)
    shapes: dict[str, list[int]] = {}
    dtypes: dict[str, str] = {}
    by_file: dict[Path, list[str]] = {}
    for name, path in index.items():
        by_file.setdefault(path, []).append(name)
    for path, names in sorted(by_file.items(), key=lambda item: str(item[0])):
        with safe_open(path, framework="pt", device="cpu") as f:
            for name in names:
                sl = f.get_slice(name)
                shapes[name] = list(sl.get_shape())
                dtypes[name] = str(sl.get_dtype())
    return shapes, dtypes


def iter_tensors(model_dir: str | Path, names: list[str] | None = None) -> Iterator[tuple[str, object, str]]:
    index = tensor_index(model_dir)
    selected = sorted(index) if names is None else names
    current_path: Path | None = None
    handle = None
    try:
        for name in selected:
            path = index[name]
            if path != current_path:
                if handle is not None:
                    handle.__exit__(None, None, None)
                handle = safe_open(path, framework="pt", device="cpu")
                handle.__enter__()
                current_path = path
            tensor = handle.get_tensor(name)
            yield name, tensor, str(tensor.dtype)
    finally:
        if handle is not None:
            handle.__exit__(None, None, None)
