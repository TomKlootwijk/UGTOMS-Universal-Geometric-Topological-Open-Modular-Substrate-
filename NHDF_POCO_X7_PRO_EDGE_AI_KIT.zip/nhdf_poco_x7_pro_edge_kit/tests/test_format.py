from pathlib import Path

import numpy as np
import pytest

from nhdf_edge.format import NHDFPackReader, NHDFPackWriter


def test_pack_read_and_parity(tmp_path: Path):
    rng = np.random.default_rng(3)
    a = rng.normal(size=(32, 64)).astype(np.float32)
    b = np.ones(64, dtype=np.float32)
    path = tmp_path / "toy.nhdfpack"
    with NHDFPackWriter(path, model_id="toy", profile_name="test") as writer:
        writer.add_quantized_tensor("a", a, bits=3)
        writer.add_fp16_tensor("b", b)

    with NHDFPackReader(path) as reader:
        ar = reader.read_tensor("a")
        br = reader.read_tensor("b")
        assert ar.shape == a.shape
        np.testing.assert_allclose(br, b, atol=1e-3)
        assert reader.verify_tensor("a") == (True, None)
        assert reader.verify_tensor_hash("a")

    # Flip one payload bit and confirm detection.
    with NHDFPackReader(path) as reader:
        offset = reader.descriptor("a")["data_offset"]
    with path.open("r+b") as f:
        f.seek(offset + 7)
        byte = f.read(1)
        f.seek(offset + 7)
        f.write(bytes([byte[0] ^ 0x01]))
    with NHDFPackReader(path) as reader:
        ok, bad = reader.verify_tensor("a")
        assert not ok
        assert bad == 0
        with pytest.raises(ValueError, match="parity mismatch"):
            reader.read_tensor("a")


def test_even_bit_fault_can_evade_parity_but_not_sha256(tmp_path: Path):
    values = np.arange(1024, dtype=np.float32) / 100.0
    path = tmp_path / "even-fault.nhdfpack"
    with NHDFPackWriter(path, model_id="toy", profile_name="test") as writer:
        writer.add_quantized_tensor("a", values, bits=3)

    with NHDFPackReader(path) as reader:
        offset = int(reader.descriptor("a")["data_offset"])
    with path.open("r+b") as f:
        f.seek(offset + 11)
        value = f.read(1)[0]
        f.seek(offset + 11)
        f.write(bytes([value ^ 0b00000011]))  # two inversions: even parity

    with NHDFPackReader(path) as reader:
        assert reader.verify_tensor("a") == (True, None)
        assert not reader.verify_tensor_hash("a")
