# Runnable baseline: official Q2_K GGUF through llama.cpp

The custom NHDF codec needs a fused transformer runtime before it can replace a
GGUF quantizer end-to-end.  This directory supplies a control path that can be
run immediately on the phone:

- model: `Qwen/Qwen2.5-14B-Instruct-GGUF`, official Q2_K (about 5.77 GB);
- runtime: llama.cpp, CPU first, Vulkan as a measured option;
- context: 2048 by default, Q8 KV where supported;
- purpose: establish memory, speed, thermal, and quality baselines before
  attributing any improvement to NHDF.

The official model repository also offers Q3_K_M (about 7.34 GB) and Q4_K_M
(about 8.99 GB).  On a 12 GB phone these are expected to be much tighter once
Android, KV cache, compute buffers, and UI memory are included.

## Procedure

1. Set `ANDROID_NDK_HOME`, install CMake/Ninja and a Vulkan SDK containing
   `glslc`.
2. Run `fetch_build_android.sh` on the host.
3. Use `fetch_q2_model.sh` to download the official Q2_K file(s).
4. Push the binaries/model to the device and run `phone_benchmark.sh`.
5. Sweep `NGL=0,12,24,48,99`; the fastest sustained setting is device/driver
   specific.  UMA does not guarantee that all-GPU is fastest.

The scripts default to llama.cpp release `b10711`, current when this kit was
created.  Override `LLAMA_CPP_REF` to test a later release and record the exact
commit in the benchmark CSV.
