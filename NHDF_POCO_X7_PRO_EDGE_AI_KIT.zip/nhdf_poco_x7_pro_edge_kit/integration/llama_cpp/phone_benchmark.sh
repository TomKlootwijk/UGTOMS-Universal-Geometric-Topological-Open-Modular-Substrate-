#!/usr/bin/env bash
set -euo pipefail

# Run on the host with adb connected.  MODEL must point to a merged GGUF file.
: "${MODEL:?Set MODEL to the local Q2_K GGUF path}"
BIN_DIR="${BIN_DIR:-$PWD/build/llama.cpp/build-android/bin}"
REMOTE="${REMOTE:-/data/local/tmp/nhdf-edge}"
CONTEXT="${CONTEXT:-2048}"
PROMPT_TOKENS="${PROMPT_TOKENS:-512}"
GEN_TOKENS="${GEN_TOKENS:-128}"
THREADS="${THREADS:-8}"
NGL_LIST="${NGL_LIST:-0 12 24 48 99}"

adb shell "mkdir -p '$REMOTE'"
adb push "$BIN_DIR/llama-bench" "$REMOTE/llama-bench"
adb push "$BIN_DIR/llama-cli" "$REMOTE/llama-cli"
adb push "$MODEL" "$REMOTE/model.gguf"
adb shell "chmod 755 '$REMOTE/llama-bench' '$REMOTE/llama-cli'"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT="benchmark-${STAMP}.log"
for ngl in $NGL_LIST; do
  echo "=== ngl=$ngl ===" | tee -a "$OUT"
  # Flags change occasionally across llama.cpp releases.  If -fa/ctk/ctv are
  # rejected, remove them and record that fact in the benchmark sheet.
  adb shell "cd '$REMOTE' && ./llama-bench -m model.gguf -p '$PROMPT_TOKENS' -n '$GEN_TOKENS' -t '$THREADS' -ngl '$ngl' -fa 1" \
    | tee -a "$OUT" || true
  adb shell "dumpsys meminfo | head -80" >> "$OUT" || true
  adb shell "dumpsys thermalservice | head -120" >> "$OUT" || true
  sleep 20
done
printf 'Saved %s\n' "$OUT"
