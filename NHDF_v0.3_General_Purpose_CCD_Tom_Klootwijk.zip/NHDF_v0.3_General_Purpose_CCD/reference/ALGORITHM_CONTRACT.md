# NHDF v0.3 elementary CCD scaffold - algorithm contract

The code in this directory is an executable reference for the *elementary* G0-G1 portion of the Version 0.3 PDF. It is deliberately dependency-free and fail-closed.

## What is implemented

- Typed objects, motions, policies, query records, result statuses, certificate classes, witnesses, normals, and TOI intervals.
- Linear sphere-sphere CCD using a cancellation-resistant quadratic formula.
- Linear sphere against a static one-sided plane.
- Translating AABB-AABB CCD using three continuous slab intervals.
- Conservative swept-AABB broad phase for spheres and translating AABBs. Unbounded planes are retained rather than falsely pruned.
- A generic conservative-advancement function driven by a caller-supplied separation lower bound and closing-speed bound.
- Explicit `UNSUPPORTED`, `INDETERMINATE`, `NUMERIC_FAILURE`, and `RESOURCE_FAILURE` vocabulary.

## Certification meaning

`CLEAR_CERTIFIED` is emitted only by an analytic backend for its exact declared linear model, or by conservative advancement when the supplied gap and closing-rate contracts prove that the remaining interval is safe. `HIT_CERTIFIED` is an analytic first root within the requested interval. `HIT_CONSERVATIVE` encloses contact but may be early or loose.

The generic conservative-advancement loop cannot verify that a user-provided oracle is truthful. An invalid lower-bound or rate-bound function invalidates the certificate. The PDF makes this dependency normative.

## What is intentionally not implemented

- Rigid rotation or acceleration envelopes.
- General convex support mapping / GJK shape casting.
- Triangle mesh BVHs, vertex-face or edge-edge root isolation.
- Deformable or topology-changing geometry.
- Self-collision filtering, simultaneous-contact manifolds, joints, or a world response solver.
- Interval arithmetic or exact predicates.
- GPU kernels.

Those are specified as later conformance levels. The package does not disguise their absence behind a generic Boolean API.

## Run

```bash
cd reference
python -m unittest -v test_nhdf_ccd_reference.py
```

The test runner in `../verification/run_tests.sh` additionally compiles the module and records the result.
