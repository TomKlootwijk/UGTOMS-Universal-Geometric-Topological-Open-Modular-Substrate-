"""Run one high-speed tunneling example and print the typed CCD result as JSON."""

from __future__ import annotations

import json

from nhdf_ccd_reference import CCDPolicy, CCDQuery, LinearMotion, MovingObject, Sphere, TimeInterval, Vec3, dispatch

moving = MovingObject(
    "fast_sphere",
    Sphere(1.0),
    LinearMotion(Vec3(-10.0, 0.0, 0.0), Vec3(30.0, 0.0, 0.0)),
)
static = MovingObject(
    "static_sphere",
    Sphere(1.0),
    LinearMotion(Vec3(0.0, 0.0, 0.0)),
)
query = CCDQuery(
    moving,
    static,
    TimeInterval(0.0, 1.0),
    CCDPolicy(time_tolerance=1.0e-8, spatial_tolerance=1.0e-9),
    "demo_fast_sphere",
)

print(json.dumps(dispatch(query).to_dict(), indent=2, sort_keys=True))
