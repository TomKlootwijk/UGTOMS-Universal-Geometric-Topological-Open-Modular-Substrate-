# NHDF Formal Specification Version 0.3
## General-Purpose Continuous Collision Detection Extension

This archive contains the upgraded NHDF/PCKF/IHCP formal specification and a small executable reference scaffold for the literal computer-graphics / physics-engine meaning of Continuous Collision Detection (CCD).

## Main deliverable

- `specification/NHDF_Formal_Specification_v0.3_General_Purpose_CCD_Tom_Klootwijk.pdf` - the 93-page formal specification.
- `specification/NHDF_v0.3.tex` - the LaTeX source used to build the PDF.

## Reference scaffold

- `reference/nhdf_ccd_reference.py` - dependency-free elementary CCD implementation.
- `reference/test_nhdf_ccd_reference.py` - unit and regression tests.
- `reference/test_vectors.json` - machine-readable analytic sphere test vectors.
- `reference/telemetry_schema.json` - draft JSON Schema for Version 0.3 query telemetry.
- `reference/backend_matrix.csv` - implemented and specified backend matrix.
- `reference/ALGORITHM_CONTRACT.md` - exact scope and certificate meaning.
- `reference/demo.py` / `reference/demo_output.json` - high-speed tunneling example and typed result.

## Verification

- `verification/run_tests.sh` - compiles and runs the Python reference tests.
- `verification/expected_test_output.txt` - captured successful test output for this release.
- `manifest.sha256` - SHA-256 digest for every packaged file except the manifest itself.

## Run the scaffold

```bash
cd verification
./run_tests.sh
```

No third-party Python packages are required.

## Scope

Version 0.3 replaces the Version 0.2 point/gap conservative-advancement block with a general-purpose *architecture*: conservative broad phase, geometry/motion capability records, backend dispatch, certified time-of-impact intervals, robust/degenerate handling, contact manifolds, simultaneous and self-collision policy, event-driven integration, response separation, bounded GPU queues, and fail-closed statuses.

The included Python code implements only elementary G0-G1 backends: linear sphere-sphere, sphere-plane, translating AABB slabs, swept-AABB broad phase, and a generic conservative-advancement example. Convex rotation, triangle meshes, deformables, exact/inclusion predicates, simultaneous world response, and GPU kernels remain specified interfaces and verification targets rather than pretending to be implemented.
