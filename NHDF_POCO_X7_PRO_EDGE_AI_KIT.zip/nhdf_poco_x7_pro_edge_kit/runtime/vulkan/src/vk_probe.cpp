#include <vulkan/vulkan.h>

#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>

static std::string version_string(uint32_t v) {
    return std::to_string(VK_VERSION_MAJOR(v)) + "." +
           std::to_string(VK_VERSION_MINOR(v)) + "." +
           std::to_string(VK_VERSION_PATCH(v));
}

int main() {
    VkApplicationInfo app{VK_STRUCTURE_TYPE_APPLICATION_INFO};
    app.pApplicationName = "nhdf-vk-probe";
    app.applicationVersion = 1;
    app.pEngineName = "NHDF";
    app.engineVersion = 1;
    app.apiVersion = VK_API_VERSION_1_1;

    VkInstanceCreateInfo ci{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};
    ci.pApplicationInfo = &app;
    VkInstance instance = VK_NULL_HANDLE;
    VkResult rc = vkCreateInstance(&ci, nullptr, &instance);
    if (rc != VK_SUCCESS) {
        std::cerr << "{\"error\":\"vkCreateInstance failed\",\"code\":" << rc << "}\n";
        return 2;
    }

    uint32_t count = 0;
    vkEnumeratePhysicalDevices(instance, &count, nullptr);
    if (count == 0) {
        std::cerr << "{\"error\":\"no Vulkan physical device\"}\n";
        vkDestroyInstance(instance, nullptr);
        return 3;
    }
    std::vector<VkPhysicalDevice> devices(count);
    vkEnumeratePhysicalDevices(instance, &count, devices.data());

    std::cout << "{\"devices\":[";
    for (uint32_t index = 0; index < count; ++index) {
        VkPhysicalDevice dev = devices[index];
        VkPhysicalDeviceProperties props{};
        vkGetPhysicalDeviceProperties(dev, &props);

        VkPhysicalDeviceShaderFloat16Int8Features f16i8{
            VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_SHADER_FLOAT16_INT8_FEATURES};
        VkPhysicalDeviceFeatures2 features{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2};
        features.pNext = &f16i8;
        vkGetPhysicalDeviceFeatures2(dev, &features);

        VkPhysicalDeviceMemoryProperties mem{};
        vkGetPhysicalDeviceMemoryProperties(dev, &mem);

        if (index) std::cout << ',';
        std::cout << "{\"name\":\"" << props.deviceName << "\""
                  << ",\"api\":\"" << version_string(props.apiVersion) << "\""
                  << ",\"driver\":" << props.driverVersion
                  << ",\"vendor_id\":" << props.vendorID
                  << ",\"device_id\":" << props.deviceID
                  << ",\"max_storage_buffer_range\":" << props.limits.maxStorageBufferRange
                  << ",\"max_compute_shared_memory\":" << props.limits.maxComputeSharedMemorySize
                  << ",\"max_compute_workgroup_invocations\":" << props.limits.maxComputeWorkGroupInvocations
                  << ",\"shader_float16\":" << (f16i8.shaderFloat16 ? "true" : "false")
                  << ",\"shader_int8\":" << (f16i8.shaderInt8 ? "true" : "false")
                  << ",\"memory_heaps\":[";
        for (uint32_t h = 0; h < mem.memoryHeapCount; ++h) {
            if (h) std::cout << ',';
            std::cout << "{\"bytes\":" << mem.memoryHeaps[h].size
                      << ",\"device_local\":"
                      << ((mem.memoryHeaps[h].flags & VK_MEMORY_HEAP_DEVICE_LOCAL_BIT) ? "true" : "false")
                      << '}';
        }
        std::cout << "],\"memory_types\":[";
        for (uint32_t t = 0; t < mem.memoryTypeCount; ++t) {
            if (t) std::cout << ',';
            const auto flags = mem.memoryTypes[t].propertyFlags;
            std::cout << "{\"heap\":" << mem.memoryTypes[t].heapIndex
                      << ",\"device_local\":" << ((flags & VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT) ? "true" : "false")
                      << ",\"host_visible\":" << ((flags & VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT) ? "true" : "false")
                      << ",\"host_coherent\":" << ((flags & VK_MEMORY_PROPERTY_HOST_COHERENT_BIT) ? "true" : "false")
                      << ",\"host_cached\":" << ((flags & VK_MEMORY_PROPERTY_HOST_CACHED_BIT) ? "true" : "false")
                      << '}';
        }
        std::cout << "]}";
    }
    std::cout << "]}\n";
    vkDestroyInstance(instance, nullptr);
    return 0;
}
