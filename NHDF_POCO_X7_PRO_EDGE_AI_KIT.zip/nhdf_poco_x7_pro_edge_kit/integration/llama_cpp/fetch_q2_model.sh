#!/usr/bin/env bash
set -euo pipefail
OUT="${1:-$PWD/models/qwen2.5-14b-q2_k}"
mkdir -p "$OUT"
python -m pip install -U huggingface_hub
huggingface-cli download Qwen/Qwen2.5-14B-Instruct-GGUF \
  --include '*q2_k*.gguf' \
  --local-dir "$OUT"
find "$OUT" -name '*.gguf' -type f -print
