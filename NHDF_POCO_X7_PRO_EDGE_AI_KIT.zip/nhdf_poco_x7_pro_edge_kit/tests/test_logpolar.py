import numpy as np

from nhdf_edge.logpolar import decode_blocks, encode_blocks


def test_logpolar_quality_improves_with_bits():
    rng = np.random.default_rng(2)
    values = rng.normal(0, 0.07, 8192).astype(np.float32)
    errors = []
    for bits in (2, 3, 4):
        encoded = encode_blocks(values, bits=bits, block_size=512, gamma=15.0)
        restored = decode_blocks(
            encoded.records,
            bits=bits,
            block_size=512,
            gamma=15.0,
            original_size=values.size,
        )
        errors.append(float(np.mean((values - restored) ** 2)))
    assert errors[2] < errors[1] < errors[0]


def test_odd_length_roundtrip_shape():
    values = np.linspace(-1, 1, 777, dtype=np.float32)
    encoded = encode_blocks(values, bits=3)
    restored = decode_blocks(encoded.records, bits=3, original_size=values.size)
    assert restored.shape == values.shape
