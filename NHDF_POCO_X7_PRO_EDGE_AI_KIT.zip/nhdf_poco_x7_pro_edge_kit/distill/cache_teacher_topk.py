#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer


def load_texts(path: Path) -> list[str]:
    texts: list[str] = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue
            item = json.loads(line)
            if "text" in item:
                texts.append(str(item["text"]))
            elif "messages" in item:
                texts.append(json.dumps(item["messages"], ensure_ascii=False))
            else:
                raise ValueError("each JSONL row needs 'text' or 'messages'")
    return texts


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--model", default="Qwen/Qwen2.5-14B-Instruct")
    p.add_argument("--dataset", required=True, help="JSONL with a text field")
    p.add_argument("--output", required=True)
    p.add_argument("--max-length", type=int, default=512)
    p.add_argument("--top-k", type=int, default=64)
    p.add_argument("--limit", type=int, default=0)
    args = p.parse_args()

    tokenizer = AutoTokenizer.from_pretrained(args.model, use_fast=True)
    model = AutoModelForCausalLM.from_pretrained(
        args.model,
        torch_dtype=torch.bfloat16,
        device_map="auto",
        low_cpu_mem_usage=True,
    ).eval()
    texts = load_texts(Path(args.dataset))
    if args.limit:
        texts = texts[: args.limit]

    records = []
    with torch.inference_mode():
        for i, text in enumerate(texts):
            batch = tokenizer(
                text,
                return_tensors="pt",
                truncation=True,
                max_length=args.max_length,
            )
            device = next(model.parameters()).device
            input_ids = batch["input_ids"].to(device)
            attention_mask = batch["attention_mask"].to(device)
            logits = model(input_ids=input_ids, attention_mask=attention_mask).logits[0, :-1].float()
            values, indices = torch.topk(logits, k=min(args.top_k, logits.shape[-1]), dim=-1)
            records.append(
                {
                    "input_ids": input_ids[0].cpu().to(torch.int32),
                    "attention_mask": attention_mask[0].cpu().to(torch.uint8),
                    "teacher_topk_indices": indices.cpu().to(torch.int32),
                    "teacher_topk_logits": values.cpu().to(torch.float16),
                }
            )
            print(json.dumps({"row": i, "tokens": int(input_ids.numel())}), flush=True)
    torch.save(
        {
            "model": args.model,
            "top_k": args.top_k,
            "max_length": args.max_length,
            "records": records,
        },
        args.output,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
