from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path
from typing import Any

from .policy import build_tensor_plans, load_profile, load_sensitivity


def _qwen25_14b_shapes(config: dict[str, Any]) -> dict[str, list[int]]:
    """Synthesize canonical tensor shapes from a Qwen2-style config.

    This is used for planning before model weights are downloaded.  The packer
    itself always enumerates the real safetensors keys.
    """
    h = int(config["hidden_size"])
    inter = int(config["intermediate_size"])
    n_layers = int(config["num_hidden_layers"])
    n_heads = int(config["num_attention_heads"])
    n_kv = int(config["num_key_value_heads"])
    head_dim = h // n_heads
    vocab = int(config["vocab_size"])
    shapes: dict[str, list[int]] = {
        "model.embed_tokens.weight": [vocab, h],
        "model.norm.weight": [h],
        "lm_head.weight": [vocab, h],
    }
    for i in range(n_layers):
        prefix = f"model.layers.{i}"
        shapes.update(
            {
                f"{prefix}.self_attn.q_proj.weight": [h, h],
                f"{prefix}.self_attn.k_proj.weight": [n_kv * head_dim, h],
                f"{prefix}.self_attn.v_proj.weight": [n_kv * head_dim, h],
                f"{prefix}.self_attn.o_proj.weight": [h, h],
                f"{prefix}.mlp.gate_proj.weight": [inter, h],
                f"{prefix}.mlp.up_proj.weight": [inter, h],
                f"{prefix}.mlp.down_proj.weight": [h, inter],
                f"{prefix}.input_layernorm.weight": [h],
                f"{prefix}.post_attention_layernorm.weight": [h],
            }
        )
    return shapes


def estimate_from_shapes(
    shapes: dict[str, list[int]],
    profile: dict,
    sensitivity: dict[str, float] | None = None,
) -> dict[str, Any]:
    plans = build_tensor_plans(shapes, profile, sensitivity or {})
    block_size = int(profile.get("quantization", {}).get("block_size", 512))
    total_params = 0
    data_bytes = 0
    parity_bytes = 0
    rows: list[dict[str, Any]] = []
    by_bits: dict[str, int] = {}

    for name, shape in shapes.items():
        numel = math.prod(shape)
        total_params += numel
        plan = plans[name]
        if plan.codec == "fp16":
            tensor_data = numel * 2
            n_blocks = math.ceil(tensor_data / 4096)
            p_bytes = math.ceil(n_blocks / 8)
        else:
            n_blocks = math.ceil(numel / block_size)
            record_bytes = 4 + block_size * plan.bits // 8
            tensor_data = n_blocks * record_bytes
            p_bytes = math.ceil(n_blocks / 8)
        data_bytes += tensor_data
        parity_bytes += p_bytes
        key = f"{plan.codec}:{plan.bits}"
        by_bits[key] = by_bits.get(key, 0) + numel
        rows.append(
            {
                "name": name,
                "numel": numel,
                "codec": plan.codec,
                "bits": plan.bits,
                "estimated_data_bytes": tensor_data,
                "parity_bytes": p_bytes,
                "reason": plan.reason,
            }
        )

    file_overhead = 2 * 1024 * 1024  # JSON table, alignment, future metadata allowance
    total_bytes = data_bytes + parity_bytes + file_overhead
    return {
        "total_parameters": total_params,
        "data_bytes": data_bytes,
        "parity_bytes": parity_bytes,
        "format_overhead_allowance_bytes": file_overhead,
        "estimated_file_bytes": total_bytes,
        "estimated_file_gb_decimal": total_bytes / 1e9,
        "estimated_file_gib": total_bytes / (1024**3),
        "effective_bits_per_weight": total_bytes * 8 / total_params,
        "parameter_mix": by_bits,
        "tensors": rows,
    }


def kv_cache_bytes(config: dict[str, Any], context: int, bytes_per_element: float = 1.0) -> int:
    h = int(config["hidden_size"])
    n_heads = int(config["num_attention_heads"])
    head_dim = h // n_heads
    n_kv = int(config["num_key_value_heads"])
    layers = int(config["num_hidden_layers"])
    elements_per_token = 2 * layers * n_kv * head_dim
    return int(elements_per_token * context * bytes_per_element)


def decode_tps(weight_gb: float, bandwidth_gbs: float, efficiency: float) -> float:
    return bandwidth_gbs * efficiency / weight_gb


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Estimate NHDF model size, KV cache, and memory-bound decode speed")
    p.add_argument("--config", required=True, help="Hugging Face config.json")
    p.add_argument("--profile", required=True, help="NHDF YAML profile")
    p.add_argument("--sensitivity", help="Optional sensitivity JSON")
    p.add_argument("--json-out")
    p.add_argument("--csv-out")
    p.add_argument("--contexts", default="2048,4096,8192")
    return p.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    config = json.loads(Path(args.config).read_text(encoding="utf-8"))
    profile = load_profile(args.profile)
    sensitivity = load_sensitivity(args.sensitivity)
    shapes = _qwen25_14b_shapes(config)
    result = estimate_from_shapes(shapes, profile, sensitivity)
    contexts = [int(x) for x in args.contexts.split(",") if x.strip()]
    result["kv_cache"] = {
        str(ctx): {
            "fp16_bytes": kv_cache_bytes(config, ctx, 2.0),
            "q8_bytes": kv_cache_bytes(config, ctx, 1.0),
            "q4_approx_bytes": kv_cache_bytes(config, ctx, 0.5),
        }
        for ctx in contexts
    }
    weight_gb = result["estimated_file_gb_decimal"]
    result["decode_roofline_tps"] = [
        {
            "sustained_bandwidth_gbs": bw,
            "kernel_efficiency": eff,
            "tokens_per_second": decode_tps(weight_gb, bw, eff),
        }
        for bw in (25, 35, 45, 55)
        for eff in (0.45, 0.55)
    ]
    print(json.dumps({k: v for k, v in result.items() if k != "tensors"}, indent=2, sort_keys=True))
    if args.json_out:
        Path(args.json_out).write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
    if args.csv_out:
        with Path(args.csv_out).open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(result["tensors"][0].keys()))
            writer.writeheader()
            writer.writerows(result["tensors"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
