# Changelog

## Version 0.3 - 31 August 2026

Focused extension for literal computer-graphics Continuous Collision Detection.

Added:

- typed CCD query, result, status, certificate, tolerance, and capability records;
- explicit certified clear/hit, conservative hit, initial contact/overlap, unsupported, indeterminate, numerical, and resource-failure semantics;
- conservative swept broad phase and complete-pair obligation;
- backend dispatch for analytic primitives, convex/rigid motion, triangle features, deformables/volumes, implicit fields, and compounds;
- angular and acceleration bounds for rigid conservative advancement;
- vertex-face and edge-edge mesh CCD requirements;
- interval/inclusion root isolation, filtered/exact predicates, degeneracy and post-check policies;
- contact manifolds, co-time grouping, persistent/self-collision, topology-change, island, and event-accumulation rules;
- event-driven integrator coupling, multi-contact response, friction, barriers, overlap recovery, and fail-safe behavior;
- bounded parallel/GPU queues, interval-aware earliest-event reduction, determinism profile, and telemetry;
- G0-G5 conformance ladder, adversarial test families, fuzz/metamorphic testing, release gates, expanded limitations, and proof sketches;
- executable standard-library Python elementary CCD scaffold with tests and schemas.

Corrected:

- an SDF endpoint sign change is not a universal no-tunneling proof;
- parity/bit flips are event or scheduling signals, not collision certificates or physical response laws;
- log-polar foveation may prioritize work but cannot discard safety-critical broad-phase candidates;
- initial penetration is a separate recovery problem, not a positive time of impact;
- unsupported or unresolved work must not become a silent clear result.

## Version 0.2 - 31 August 2026

Roads Technology commute extension: log-polar Jacobian, transforms, observer conditioning, attention/interrupt, adaptive timeline, initial conservative contact profile, acoustics, provenance, and responsible public-safety constraints.

## Version 0.1 - 31 August 2026

Initial non-degenerate NHDF/PCKF/IHCP formalization with local zero sets, typed operator chain, bounded routing, causal timeline, GPU/optical/SAR extensions, and validation program.
