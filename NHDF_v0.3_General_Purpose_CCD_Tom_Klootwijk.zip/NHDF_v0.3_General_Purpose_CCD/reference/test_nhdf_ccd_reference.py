from __future__ import annotations

import json
import math
from pathlib import Path
import unittest

from nhdf_ccd_reference import (
    AABB,
    CCDPolicy,
    CCDQuery,
    CertificateClass,
    LinearMotion,
    MovingObject,
    Plane,
    ResultStatus,
    Sphere,
    TimeInterval,
    Vec3,
    broad_phase,
    conservative_advancement,
    dispatch,
    moving_sphere_static_sphere_oracle,
)


def obj(object_id: str, shape, position: Vec3, velocity: Vec3 = Vec3(0.0, 0.0, 0.0)) -> MovingObject:
    return MovingObject(object_id, shape, LinearMotion(position, velocity))


class ElementaryCCDTests(unittest.TestCase):
    def setUp(self) -> None:
        self.interval = TimeInterval(0.0, 1.0)
        self.policy = CCDPolicy(time_tolerance=1.0e-8, spatial_tolerance=1.0e-9)

    def test_high_speed_sphere_tunneling_is_detected(self) -> None:
        a = obj("fast", Sphere(1.0), Vec3(-10.0, 0.0, 0.0), Vec3(30.0, 0.0, 0.0))
        b = obj("wall_proxy", Sphere(1.0), Vec3(0.0, 0.0, 0.0))
        r = dispatch(CCDQuery(a, b, self.interval, self.policy, "tunnel"))
        self.assertEqual(r.status, ResultStatus.HIT_CERTIFIED)
        self.assertEqual(r.certificate, CertificateClass.ANALYTIC_BOUNDED)
        self.assertIsNotNone(r.toi)
        self.assertAlmostEqual((r.toi.start + r.toi.end) * 0.5, 8.0 / 30.0, places=6)

    def test_sphere_miss_is_clear(self) -> None:
        a = obj("a", Sphere(1.0), Vec3(-5.0, 3.0, 0.0), Vec3(10.0, 0.0, 0.0))
        b = obj("b", Sphere(1.0), Vec3(0.0, 0.0, 0.0))
        r = dispatch(CCDQuery(a, b, self.interval, self.policy))
        self.assertEqual(r.status, ResultStatus.CLEAR_CERTIFIED)

    def test_sphere_tangent_double_root(self) -> None:
        a = obj("a", Sphere(1.0), Vec3(-5.0, 2.0, 0.0), Vec3(10.0, 0.0, 0.0))
        b = obj("b", Sphere(1.0), Vec3(0.0, 0.0, 0.0))
        r = dispatch(CCDQuery(a, b, self.interval, self.policy))
        self.assertEqual(r.status, ResultStatus.HIT_CERTIFIED)
        self.assertIsNotNone(r.toi)
        self.assertAlmostEqual((r.toi.start + r.toi.end) * 0.5, 0.5, places=6)

    def test_initial_overlap_is_not_reported_as_toi(self) -> None:
        a = obj("a", Sphere(1.0), Vec3(0.5, 0.0, 0.0))
        b = obj("b", Sphere(1.0), Vec3(0.0, 0.0, 0.0))
        r = dispatch(CCDQuery(a, b, self.interval, self.policy))
        self.assertEqual(r.status, ResultStatus.INITIAL_OVERLAP)
        self.assertEqual(r.toi, TimeInterval(0.0, 0.0))

    def test_initial_contact_is_distinct(self) -> None:
        a = obj("a", Sphere(1.0), Vec3(2.0, 0.0, 0.0))
        b = obj("b", Sphere(1.0), Vec3(0.0, 0.0, 0.0))
        r = dispatch(CCDQuery(a, b, self.interval, self.policy))
        self.assertEqual(r.status, ResultStatus.INITIAL_CONTACT)

    def test_sphere_plane(self) -> None:
        sphere = obj("s", Sphere(0.5), Vec3(0.0, 5.0, 0.0), Vec3(0.0, -10.0, 0.0))
        plane = obj("p", Plane(Vec3(0.0, 1.0, 0.0), 0.0), Vec3(0.0, 0.0, 0.0))
        r = dispatch(CCDQuery(sphere, plane, self.interval, self.policy))
        self.assertEqual(r.status, ResultStatus.HIT_CERTIFIED)
        self.assertAlmostEqual((r.toi.start + r.toi.end) * 0.5, 0.45, places=6)

    def test_aabb_slab_toi(self) -> None:
        a = obj("a", AABB(Vec3(1.0, 1.0, 1.0)), Vec3(-5.0, 0.0, 0.0), Vec3(10.0, 0.0, 0.0))
        b = obj("b", AABB(Vec3(1.0, 1.0, 1.0)), Vec3(0.0, 0.0, 0.0))
        r = dispatch(CCDQuery(a, b, self.interval, self.policy))
        self.assertEqual(r.status, ResultStatus.HIT_CERTIFIED)
        self.assertAlmostEqual((r.toi.start + r.toi.end) * 0.5, 0.3, places=6)

    def test_swept_broad_phase_keeps_fast_crossing_pair(self) -> None:
        a = obj("a", Sphere(0.1), Vec3(-100.0, 0.0, 0.0), Vec3(200.0, 0.0, 0.0))
        b = obj("b", Sphere(0.1), Vec3(0.0, 0.0, 0.0))
        pairs, decisions = broad_phase([a, b], self.interval)
        self.assertEqual(pairs, [(0, 1)])
        self.assertTrue(decisions[0].candidate)

    def test_broad_phase_rejects_disjoint_sweeps(self) -> None:
        a = obj("a", Sphere(1.0), Vec3(-10.0, 0.0, 0.0), Vec3(-1.0, 0.0, 0.0))
        b = obj("b", Sphere(1.0), Vec3(10.0, 0.0, 0.0), Vec3(1.0, 0.0, 0.0))
        pairs, decisions = broad_phase([a, b], self.interval)
        self.assertEqual(pairs, [])
        self.assertFalse(decisions[0].candidate)

    def test_unregistered_pair_is_explicitly_unsupported(self) -> None:
        plane_a = obj("p1", Plane(Vec3(1.0, 0.0, 0.0), 0.0), Vec3(0.0, 0.0, 0.0))
        plane_b = obj("p2", Plane(Vec3(0.0, 1.0, 0.0), 0.0), Vec3(0.0, 0.0, 0.0))
        r = dispatch(CCDQuery(plane_a, plane_b, self.interval, self.policy))
        self.assertEqual(r.status, ResultStatus.UNSUPPORTED)

    def test_conservative_advancement_reports_conservative_hit(self) -> None:
        moving = obj("moving", Sphere(0.5), Vec3(-5.0, 0.0, 0.0), Vec3(10.0, 0.0, 0.0))
        static = obj("static", Sphere(0.5), Vec3(0.0, 0.0, 0.0))
        separation, closing = moving_sphere_static_sphere_oracle(moving, static)
        r = conservative_advancement(
            object_a="moving",
            object_b="static",
            interval=self.interval,
            policy=CCDPolicy(
                time_tolerance=1.0e-8,
                spatial_tolerance=1.0e-7,
                safety_factor=0.8,
                minimum_time_progress=1.0e-10,
                max_iterations=256,
            ),
            separation=separation,
            closing_speed_bound=closing,
        )
        self.assertEqual(r.status, ResultStatus.HIT_CONSERVATIVE)
        self.assertEqual(r.certificate, CertificateClass.CONSERVATIVE_ADVANCEMENT)
        self.assertLessEqual(r.toi.start, 0.4)
        self.assertGreaterEqual(r.toi.end, 0.4 - 1.0e-6)

    def test_json_reference_vectors(self) -> None:
        path = Path(__file__).with_name("test_vectors.json")
        vectors = json.loads(path.read_text(encoding="utf-8"))
        for case in vectors["cases"]:
            with self.subTest(case=case["id"]):
                shape_a = Sphere(case["a"]["radius"])
                shape_b = Sphere(case["b"]["radius"])
                a = obj(case["a"]["id"], shape_a, Vec3(*case["a"]["position"]), Vec3(*case["a"]["velocity"]))
                b = obj(case["b"]["id"], shape_b, Vec3(*case["b"]["position"]), Vec3(*case["b"]["velocity"]))
                policy = CCDPolicy(minimum_separation=case.get("minimum_separation", 0.0))
                r = dispatch(CCDQuery(a, b, TimeInterval(*case["interval"]), policy, case["id"]))
                self.assertEqual(r.status.value, case["expected_status"])
                if "expected_toi" in case:
                    midpoint = (r.toi.start + r.toi.end) * 0.5
                    self.assertTrue(math.isclose(midpoint, case["expected_toi"], abs_tol=1.0e-6))


if __name__ == "__main__":
    unittest.main(verbosity=2)
