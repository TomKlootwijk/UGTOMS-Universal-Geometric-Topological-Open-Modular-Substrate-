# NHDF POCO X7 Pro Edge AI Kit

A research engineering package for compressing and deploying
`Qwen/Qwen2.5-14B-Instruct` on the **12 GB POCO X7 Pro**.  The design is grounded
in the supplied *Non-Euclidean Holographic Data Fields* formal specification and
keeps its normative operator order:

`ELP -> B0 -> P -> RBST -> K_T-> -> S_cone -> Pi -> U`

The practical AI adapter uses that order as follows:

- **ELP** pairs centered weights and log-polar encodes radius/angle;
- **B0** stores a local anchor and scale so decoded weights satisfy a local
  reconstruction zero-set;
- **P** stores one XOR parity bit per fixed block record;
- **RBST** is a bounded sensitivity tree that assigns whole tensors to 2-, 3-,
  or 4-bit leaves;
- **K_T->** orders layers and generation-tagged buffers causally;
- **S_cone** is implemented as fused dequantization plus GEMV/GEMM sweep;
- **Pi** produces logits/tokens and telemetry;
- **U** feeds quality and device measurements back into the precision plan and
  LoRA recovery stage.

## What is included

- a detailed PDF design and feasibility report;
- an executable Python `.nhdfpack` writer/reader and parity verifier;
- mixed-precision size/KV/decode-roofline estimators;
- weight-only sensitivity calibration and teacher-logit/LoRA recovery templates;
- a correctness-oriented Vulkan log-polar matvec shader and Mali feature probe;
- an immediately runnable **official Q2_K GGUF + llama.cpp baseline** path;
- tests, toy artifacts, device/benchmark scripts, and CSV templates.

No Qwen weights are included.  Downloading, training, conversion, and model
license compliance remain with the user.

## Engineering conclusion

The target is **feasible but tight** on the 12 GB variant, not on the 8 GB
variant.  The balanced estimator produces about **4.96 GB decimal** of packed
weights (about 4.62 GiB) before runtime allocations.  With a 4096-token Q8 KV
cache and planning allowances, the process target is about **6.4 GiB resident**.
Actual free RAM and Vulkan allocation behavior must be measured on the phone.

This package does **not** claim that NHDF already outperforms mature Q2/Q3
quantizers.  The custom codec and shaders are a reproducible hypothesis.  The
Q2_K baseline exists so CODEX can falsify or validate any claimed improvement.

## Quick start: package smoke test

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e '.[dev]'
pytest
python -m nhdf_edge.toy --out-dir samples
python -m nhdf_edge.inspect_pack samples/toy_qwenish.nhdfpack --verify
```

In an already provisioned Python environment, the repository also has an
offline-safe smoke path that does not contact a package index:

```bash
bash scripts/smoke_test.sh
```

## Estimate the full model before downloading weights

```bash
nhdf-estimate \
  --config configs/qwen2_5_14b_config.json \
  --profile configs/qwen2_5_14b_nhdf_mp275.yaml \
  --json-out metrics/nhdf_mp275_estimate.json \
  --csv-out metrics/nhdf_mp275_tensor_plan.csv
```

## Build a sensitivity plan and pack the downloaded HF model

```bash
nhdf-sensitivity \
  --model-dir /models/Qwen2.5-14B-Instruct \
  --profile configs/qwen2_5_14b_nhdf_mp275.yaml \
  --output /models/qwen14b.sensitivity.json

nhdf-pack \
  --model-dir /models/Qwen2.5-14B-Instruct \
  --profile configs/qwen2_5_14b_nhdf_mp275.yaml \
  --sensitivity /models/qwen14b.sensitivity.json \
  --output /models/qwen2.5-14b-instruct.nhdfpack

nhdf-inspect /models/qwen2.5-14b-instruct.nhdfpack --verify --verify-hash
```

The packer processes one tensor at a time, but the 29.5 GB BF16 source and final
pack still require substantial host storage.  Distillation/LoRA recovery should
be run on a capable workstation, not the phone.

## Run the mature baseline on the phone

See `integration/llama_cpp/README.md`.  In outline:

```bash
export ANDROID_NDK_HOME=/path/to/android-ndk
integration/llama_cpp/fetch_build_android.sh
integration/llama_cpp/fetch_q2_model.sh
MODEL=/path/to/q2_k.gguf integration/llama_cpp/phone_benchmark.sh
```

Sweep CPU, Vulkan, and hybrid layer counts.  The Mali GPU and CPU share LPDDR5X,
so simultaneous bandwidth-heavy execution can reduce rather than increase
speed.

## Expected, not yet measured, speed

For the balanced 4.96 GB pack, a memory-bound estimate with 25-55 GB/s sustained
model-read bandwidth and 45-55% kernel efficiency is roughly **2.3-6.1 tokens/s**
for single-token decode.  The report uses a more conservative operating band of
**2.5-5.5 tokens/s**, with lower sustained values possible under thermal
throttling.  Prefill should benefit more from Vulkan batching, but must be
measured.

## Directory map

- `docs/` - final report and source notes;
- `configs/` - POCO and Qwen profiles;
- `nhdf_edge/` - packer, reader, planner, estimator, parity and codec;
- `distill/` - teacher cache and LoRA recovery templates;
- `runtime/vulkan/` - device probe and core shaders;
- `integration/llama_cpp/` - runnable Q2_K control and integration plan;
- `metrics/` - projected tables and benchmark template;
- `samples/` - small model and pack for smoke tests;
- `tests/` - deterministic codec/format/estimator tests.

## Critical limits

1. A globally identical `SDF = 0` field is degenerate.  This implementation uses
   cell-local reconstruction constraints.
2. One-bit parity detects odd fault counts only.  It cannot locate or repair a
   damaged block.  The pack index also stores per-tensor SHA-256 values and
   `nhdf-inspect --verify-hash` can catch parity's even-fault blind spot, but it
   still does not repair corruption.
3. The custom log-polar codec has not yet demonstrated superior perplexity or
   task accuracy at equal size.
4. The Vulkan shader is a reference kernel, not a full transformer runtime.
5. Android's 12 GB is shared system memory, not dedicated GPU VRAM.
6. Model speed, available RAM, driver stability, and thermal behavior must be
   measured on the specific device and OS build.
