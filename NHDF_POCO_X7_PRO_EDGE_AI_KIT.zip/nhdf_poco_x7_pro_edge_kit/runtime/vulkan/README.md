# Vulkan/Mali runtime notes

The shaders are operator kernels, not a complete transformer implementation.
They are intended to be integrated into llama.cpp, MLC/TVM, or a purpose-built
runtime after the Python reference codec passes equivalence tests.

## Why Vulkan

The Mali-G720 is exposed through Android's Vulkan driver.  The phone uses shared
LPDDR5X rather than discrete VRAM, so the runtime should probe for a memory type
that is both host-visible and device-local/coherent, allocate model arenas in
bounded chunks, and avoid a second resident copy.  Android Hardware Buffers are
useful when Java, camera, NPU, or another process must share an activation
buffer; plain mapped Vulkan buffers are usually simpler for static weights.

## Build the device probe

Use the Android NDK toolchain and a Vulkan SDK that provides `glslc`:

```bash
cmake -S runtime/vulkan -B build/vk-probe \
  -DCMAKE_TOOLCHAIN_FILE="$ANDROID_NDK_HOME/build/cmake/android.toolchain.cmake" \
  -DANDROID_ABI=arm64-v8a -DANDROID_PLATFORM=android-29
cmake --build build/vk-probe -j
adb push build/vk-probe/nhdf-vk-probe /data/local/tmp/
adb shell /data/local/tmp/nhdf-vk-probe
```

Compile shaders separately:

```bash
glslc runtime/vulkan/shaders/nhdf_lp_matvec.comp -O \
  -o build/nhdf_lp_matvec.comp.spv
glslc runtime/vulkan/shaders/nhdf_parity_verify.comp -O \
  -o build/nhdf_parity_verify.comp.spv
```

## Mali tuning sequence

1. Verify scalar correctness against `NHDFPackReader.read_tensor`.
2. Split metadata and code payload into separate storage buffers.
3. Benchmark workgroup sizes 32, 64, and 128; do not assume desktop subgroup
   behavior.
4. Replace trigonometric operations with the supplied angle LUT.
5. Fuse dequantization with GEMV for decode and GEMM tiles for prefill.
6. Measure CPU-only, GPU-only, and hybrid schedules.  CPU and GPU share the
   same LPDDR5X bandwidth, so concurrent execution can be slower.
7. Keep a driver-safe mode: smaller batches, bounded command buffers, and a
   foreground activity during long runs.
