# Source boundary and traceability

## Supplied source material

1. `NHDF_Formal_Specification_Tom_Klootwijk(1).pdf`, Version 0.1, 31 August
   2026.  The implementation follows its local zero-set semantics, typed
   operator chain, causal timeline, bounded pools, parity limitation, GPU
   sequencing, telemetry contract, and falsifiable-validation program.
2. `1bit-parity-bit-lower-case-phi-jitter-log-encoded-polar-LUT-analytic-...pdf`,
   a 30-page exported prompt transcript.  It supplies the original vocabulary,
   application ideas, operator reordering, distributed apex concept, quantum/
   optical extension, SAR framing, and present-day GPU motivation.

## Source-derived elements

- `ELP -> B0 -> P -> RBST -> K_T-> -> S_cone -> Pi -> U` order;
- local, non-degenerate zero-level constraints rather than a global zero field;
- parity as an event gate with known even-fault blind spots;
- golden-ratio / second-phase-difference modulation of bounded branching;
- generation-tagged forward timeline;
- explicit feedback and telemetry;
- correctness-first CPU/GPU equivalence testing.

## Engineering extensions made in this kit

- selecting Qwen2.5-14B-Instruct as the teacher/deployment architecture;
- paired log-polar block quantization with 512-weight records;
- whole-tensor 2/3/4-bit mixed-precision allocation;
- same-architecture top-k-logit distillation and LoRA recovery;
- Mali Vulkan shader mapping, shared-memory policy, KV-cache profile;
- resource and speed estimates for the POCO X7 Pro;
- llama.cpp Q2_K/Q3_K_M control experiments.

These extensions are hypotheses and implementation choices, not claims already
established by the source documents.
