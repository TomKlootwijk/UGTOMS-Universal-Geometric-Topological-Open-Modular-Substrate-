import json
from pathlib import Path

from nhdf_edge.estimate import _qwen25_14b_shapes, estimate_from_shapes, kv_cache_bytes
from nhdf_edge.policy import _golden_spread, load_profile

ROOT = Path(__file__).resolve().parents[1]


def test_qwen_parameter_count_and_size():
    config = json.loads((ROOT / "configs/qwen2_5_14b_config.json").read_text())
    shapes = _qwen25_14b_shapes(config)
    profile = load_profile(ROOT / "configs/qwen2_5_14b_nhdf_mp275.yaml")
    result = estimate_from_shapes(shapes, profile)
    assert 14.7e9 < result["total_parameters"] < 14.9e9
    assert 4.8 < result["estimated_file_gb_decimal"] < 5.4
    assert 2.6 < result["effective_bits_per_weight"] < 3.0


def test_kv_cache_q8_4096():
    config = json.loads((ROOT / "configs/qwen2_5_14b_config.json").read_text())
    value = kv_cache_bytes(config, 4096, 1.0)
    assert value == 402653184  # 384 MiB


def test_golden_spread_small_budget_is_bounded():
    names = [f"model.layers.{i}.mlp.up_proj.weight" for i in range(12)]
    assert len(_golden_spread(names, 1)) == 1
    assert len(_golden_spread(names, 2)) == 2
    assert len(_golden_spread(names, 3)) == 3
