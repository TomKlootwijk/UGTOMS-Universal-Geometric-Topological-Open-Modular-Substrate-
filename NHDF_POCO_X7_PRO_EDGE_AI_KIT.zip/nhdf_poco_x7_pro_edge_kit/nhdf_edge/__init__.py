"""NHDF edge reference tools.

This package is a semantics-first prototype.  It implements an experimental
log-polar weight codec, bounded packing format, parity verification, policy
planning, and resource estimation.  It is not a complete transformer runtime.
"""

from .format import NHDFPackReader, NHDFPackWriter
from .logpolar import decode_blocks, encode_blocks

__all__ = [
    "NHDFPackReader",
    "NHDFPackWriter",
    "encode_blocks",
    "decode_blocks",
]

__version__ = "0.1.0"
