# Version 0.3 release checks

- LaTeX build completed with `-halt-on-error`.
- No unresolved citations or references were reported in the final build log.
- No overfull boxes were reported in the final build log.
- Final PDF: 93 A4 pages, openable and unencrypted.
- All PDF fonts reported by `pdffonts` are embedded and subset.
- The final PDF was rendered to 93 PNG pages at 160 dpi and visually inspected, including the landscape dispatch matrix, code listing, normative formula box, tables, and final appendices.
- Extracted text contains no Unicode replacement characters.
- Python module and tests compile with `py_compile`.
- 12 unit/regression tests pass.
- JSON test vectors, demo output, and telemetry schema parse successfully.
- CSV backend matrix parses successfully.

The checks establish packaging and elementary-reference consistency. They do not constitute proof that all general-purpose backends specified in the PDF have been implemented.
