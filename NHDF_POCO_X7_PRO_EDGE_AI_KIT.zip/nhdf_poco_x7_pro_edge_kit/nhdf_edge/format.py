from __future__ import annotations

import hashlib
import json
import math
import os
import struct
from dataclasses import dataclass
from pathlib import Path
from typing import Any, BinaryIO, Iterable

import numpy as np

from .bitpack import pack_parity_bits, parity_rows, unpack_parity_bits
from .logpolar import decode_blocks, encode_blocks

MAGIC = b"NHDFPK01"
VERSION = 1
PREAMBLE = struct.Struct("<8sI4xQQ")  # magic, version, JSON offset, JSON length
ALIGNMENT = 64


def _align(file: BinaryIO, alignment: int = ALIGNMENT) -> int:
    pos = file.tell()
    pad = (-pos) % alignment
    if pad:
        file.write(b"\x00" * pad)
    return file.tell()


def _json_dumps(value: Any) -> bytes:
    return json.dumps(value, indent=2, sort_keys=True, ensure_ascii=True).encode("utf-8")


@dataclass
class TensorDescriptor:
    name: str
    shape: list[int]
    numel: int
    codec: str
    bits: int | None
    block_size: int
    gamma: float
    data_offset: int
    data_nbytes: int
    parity_offset: int
    parity_nbytes: int
    block_count: int
    record_bytes: int | None
    source_dtype: str
    sha256: str

    def as_dict(self) -> dict[str, Any]:
        return self.__dict__.copy()


class NHDFPackWriter:
    """Streaming writer for the NHDFPK01 research format."""

    def __init__(
        self,
        path: str | os.PathLike[str],
        *,
        model_id: str,
        profile_name: str,
        operator_order: Iterable[str] = ("ELP", "B0", "P", "RBST", "K_T", "S_cone", "Pi", "U"),
        metadata: dict[str, Any] | None = None,
    ) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._f = self.path.open("wb+")
        self._f.write(b"\x00" * PREAMBLE.size)
        self._tensors: list[TensorDescriptor] = []
        self._closed = False
        self.model_id = model_id
        self.profile_name = profile_name
        self.operator_order = list(operator_order)
        self.metadata = metadata or {}

    def add_quantized_tensor(
        self,
        name: str,
        values: np.ndarray,
        *,
        bits: int,
        block_size: int = 512,
        gamma: float = 15.0,
        source_dtype: str = "unknown",
        blocks_per_chunk: int = 4096,
    ) -> TensorDescriptor:
        if self._closed:
            raise RuntimeError("writer is closed")
        arr = np.asarray(values, dtype=np.float32)
        shape = list(arr.shape)
        flat = arr.reshape(-1)
        n_blocks = math.ceil(flat.size / block_size)
        payload_bytes = block_size * bits // 8
        record_bytes = 4 + payload_bytes

        _align(self._f)
        data_offset = self._f.tell()
        parity_parts: list[np.ndarray] = []
        hasher = hashlib.sha256()
        stride = block_size * blocks_per_chunk
        for start in range(0, flat.size, stride):
            encoded = encode_blocks(flat[start : start + stride], bits=bits, block_size=block_size, gamma=gamma)
            self._f.write(encoded.records)
            hasher.update(encoded.records)
            parity_parts.append(encoded.parity)
        data_nbytes = self._f.tell() - data_offset
        if data_nbytes != n_blocks * record_bytes:
            raise AssertionError(f"record size mismatch for {name}: {data_nbytes} != {n_blocks * record_bytes}")

        parity = np.concatenate(parity_parts) if parity_parts else np.empty(0, dtype=np.uint8)
        parity_blob = pack_parity_bits(parity)
        _align(self._f)
        parity_offset = self._f.tell()
        self._f.write(parity_blob)

        desc = TensorDescriptor(
            name=name,
            shape=shape,
            numel=int(flat.size),
            codec="logpolar",
            bits=bits,
            block_size=block_size,
            gamma=gamma,
            data_offset=data_offset,
            data_nbytes=data_nbytes,
            parity_offset=parity_offset,
            parity_nbytes=len(parity_blob),
            block_count=n_blocks,
            record_bytes=record_bytes,
            source_dtype=source_dtype,
            sha256=hasher.hexdigest(),
        )
        self._tensors.append(desc)
        return desc

    def add_fp16_tensor(
        self,
        name: str,
        values: np.ndarray,
        *,
        source_dtype: str = "unknown",
        parity_block_bytes: int = 4096,
    ) -> TensorDescriptor:
        if self._closed:
            raise RuntimeError("writer is closed")
        arr = np.asarray(values, dtype=np.float32)
        shape = list(arr.shape)
        raw = arr.astype("<f2").tobytes()
        _align(self._f)
        data_offset = self._f.tell()
        self._f.write(raw)
        data_nbytes = len(raw)

        n_blocks = math.ceil(data_nbytes / parity_block_bytes)
        padded = np.zeros(n_blocks * parity_block_bytes, dtype=np.uint8)
        padded[:data_nbytes] = np.frombuffer(raw, dtype=np.uint8)
        parity = parity_rows(padded.reshape(n_blocks, parity_block_bytes)) if n_blocks else np.empty(0, dtype=np.uint8)
        parity_blob = pack_parity_bits(parity)
        _align(self._f)
        parity_offset = self._f.tell()
        self._f.write(parity_blob)

        desc = TensorDescriptor(
            name=name,
            shape=shape,
            numel=int(arr.size),
            codec="fp16",
            bits=16,
            block_size=parity_block_bytes,
            gamma=0.0,
            data_offset=data_offset,
            data_nbytes=data_nbytes,
            parity_offset=parity_offset,
            parity_nbytes=len(parity_blob),
            block_count=n_blocks,
            record_bytes=None,
            source_dtype=source_dtype,
            sha256=hashlib.sha256(raw).hexdigest(),
        )
        self._tensors.append(desc)
        return desc

    def close(self) -> None:
        if self._closed:
            return
        _align(self._f)
        json_offset = self._f.tell()
        header = {
            "format": "NHDFPK01",
            "version": VERSION,
            "model_id": self.model_id,
            "profile_name": self.profile_name,
            "operator_order": self.operator_order,
            "semantic_notice": (
                "Each decoded block satisfies a local reconstruction constraint; "
                "one-bit parity is a detector/event gate, not an error-correcting code."
            ),
            "metadata": self.metadata,
            "tensors": [t.as_dict() for t in self._tensors],
        }
        blob = _json_dumps(header)
        self._f.write(blob)
        self._f.seek(0)
        self._f.write(PREAMBLE.pack(MAGIC, VERSION, json_offset, len(blob)))
        self._f.flush()
        os.fsync(self._f.fileno())
        self._f.close()
        self._closed = True

    def __enter__(self) -> "NHDFPackWriter":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        if exc_type is None:
            self.close()
        else:
            self._f.close()
            self._closed = True


class NHDFPackReader:
    def __init__(self, path: str | os.PathLike[str]) -> None:
        self.path = Path(path)
        self._f = self.path.open("rb")
        preamble = self._f.read(PREAMBLE.size)
        if len(preamble) != PREAMBLE.size:
            raise ValueError("truncated NHDF pack")
        magic, version, json_offset, json_length = PREAMBLE.unpack(preamble)
        if magic != MAGIC:
            raise ValueError("not an NHDFPK01 file")
        if version != VERSION:
            raise ValueError(f"unsupported format version {version}")
        self._f.seek(json_offset)
        self.header = json.loads(self._f.read(json_length).decode("utf-8"))
        self.tensors = {t["name"]: t for t in self.header["tensors"]}

    def close(self) -> None:
        self._f.close()

    def __enter__(self) -> "NHDFPackReader":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def descriptor(self, name: str) -> dict[str, Any]:
        try:
            return self.tensors[name]
        except KeyError as exc:
            raise KeyError(f"tensor not found: {name}") from exc

    def read_tensor(self, name: str, *, verify: bool = True) -> np.ndarray:
        d = self.descriptor(name)
        self._f.seek(d["data_offset"])
        raw = self._f.read(d["data_nbytes"])
        if len(raw) != d["data_nbytes"]:
            raise ValueError("truncated tensor data")
        if verify:
            ok, bad = self.verify_tensor(name, raw_override=raw)
            if not ok:
                raise ValueError(f"parity mismatch in {name}; first bad block {bad}")

        if d["codec"] == "fp16":
            arr = np.frombuffer(raw, dtype="<f2").astype(np.float32)
        elif d["codec"] == "logpolar":
            arr = decode_blocks(
                raw,
                bits=int(d["bits"]),
                block_size=int(d["block_size"]),
                gamma=float(d["gamma"]),
                original_size=int(d["numel"]),
            )
        else:
            raise ValueError(f"unknown codec {d['codec']}")
        return arr.reshape(d["shape"])

    def verify_tensor_hash(self, name: str, *, raw_override: bytes | None = None) -> bool:
        """Verify the descriptor SHA-256 over the tensor record stream.

        This catches even-numbered bit faults that one-bit parity can miss.  It
        is intentionally separate because hashing a multi-gigabyte tensor has
        a higher startup cost than block-local parity.
        """
        d = self.descriptor(name)
        if raw_override is None:
            self._f.seek(d["data_offset"])
            raw = self._f.read(d["data_nbytes"])
        else:
            raw = raw_override
        if len(raw) != int(d["data_nbytes"]):
            return False
        return hashlib.sha256(raw).hexdigest() == str(d["sha256"])

    def verify_tensor(self, name: str, *, raw_override: bytes | None = None) -> tuple[bool, int | None]:
        d = self.descriptor(name)
        if raw_override is None:
            self._f.seek(d["data_offset"])
            raw = self._f.read(d["data_nbytes"])
        else:
            raw = raw_override
        self._f.seek(d["parity_offset"])
        stored_blob = self._f.read(d["parity_nbytes"])
        stored = unpack_parity_bits(stored_blob, int(d["block_count"]))

        if d["codec"] == "logpolar":
            record_bytes = int(d["record_bytes"])
            rows = np.frombuffer(raw, dtype=np.uint8).reshape(-1, record_bytes)
            actual = parity_rows(rows)
        else:
            block_size = int(d["block_size"])
            n_blocks = int(d["block_count"])
            padded = np.zeros(n_blocks * block_size, dtype=np.uint8)
            padded[: len(raw)] = np.frombuffer(raw, dtype=np.uint8)
            actual = parity_rows(padded.reshape(n_blocks, block_size)) if n_blocks else np.empty(0, dtype=np.uint8)

        mismatch = np.flatnonzero(actual != stored)
        if mismatch.size:
            return False, int(mismatch[0])
        return True, None

    def summary(self) -> dict[str, Any]:
        total_params = sum(int(t["numel"]) for t in self.header["tensors"])
        payload_bytes = sum(int(t["data_nbytes"]) + int(t["parity_nbytes"]) for t in self.header["tensors"])
        effective_bpw = payload_bytes * 8 / total_params if total_params else 0.0
        return {
            "path": str(self.path),
            "model_id": self.header.get("model_id"),
            "profile_name": self.header.get("profile_name"),
            "tensor_count": len(self.header["tensors"]),
            "parameter_count": total_params,
            "payload_bytes": payload_bytes,
            "file_bytes": self.path.stat().st_size,
            "effective_bits_per_weight": effective_bpw,
        }
