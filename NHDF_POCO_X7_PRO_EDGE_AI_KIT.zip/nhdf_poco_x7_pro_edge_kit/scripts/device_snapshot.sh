#!/usr/bin/env bash
set -euo pipefail
OUT="${1:-device-snapshot-$(date -u +%Y%m%dT%H%M%SZ).txt}"
{
  echo '=== getprop ==='
  adb shell getprop
  echo '=== meminfo ==='
  adb shell cat /proc/meminfo
  echo '=== SurfaceFlinger/GPU ==='
  adb shell dumpsys SurfaceFlinger 2>/dev/null | grep -i -E 'vulkan|gles|gpu|driver' || true
  echo '=== thermal ==='
  adb shell dumpsys thermalservice || true
  echo '=== power ==='
  adb shell dumpsys battery || true
} > "$OUT"
printf 'Saved %s\n' "$OUT"
