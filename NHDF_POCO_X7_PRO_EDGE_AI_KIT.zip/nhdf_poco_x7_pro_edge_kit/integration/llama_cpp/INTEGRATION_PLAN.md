# Proposed llama.cpp integration for NHDFPK01

A production integration should not decode the whole model to FP16.  Add three
new read-only tensor types (`NHDF_LP2`, `NHDF_LP3`, `NHDF_LP4`) and fuse their
pair decoder into matrix-vector and matrix-matrix kernels.

Required changes, in order:

1. **GGUF or sidecar loader**: map each tensor name to its NHDF section and
   expose fixed record size, block size, bit width, gamma, and parity bitmap.
2. **CPU reference traits**: implement row size, dequantization, dot product,
   and parity verification.  Use these for deterministic equivalence tests.
3. **Vulkan storage**: upload or map code payload and mean/scale arrays in
   bounded chunks; never create a second full-model copy.
4. **Vulkan GEMV**: integrate `nhdf_lp_matvec.comp` for single-token decode.
5. **Vulkan GEMM**: add tiled prefill kernels; this is likely where Mali gives
   the clearest gain.
6. **Scheduler**: benchmark CPU, GPU, and hybrid layer placement.  Because the
   CPU and GPU share LPDDR5X, avoid simultaneous bandwidth-heavy kernels.
7. **Fault path**: on parity mismatch, reject the block, reload it from the
   read-only pack, and enter safe mode after a configurable error rate.  Parity
   alone cannot repair an even number of bit flips.
8. **Telemetry**: log generation, tensor, block, parity event rate, saturation,
   peak resident memory, prompt tokens/s, generation tokens/s, and temperature.

Do not claim an NHDF speed or quality advantage until the custom kernels beat
Q2_K and Q3_K_M at matched memory and quality on the same device.
