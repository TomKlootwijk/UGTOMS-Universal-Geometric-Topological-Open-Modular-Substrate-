# Build the specification

A TeX Live installation with `latexmk`, `pdflatex`, TikZ, `tcolorbox`, `listings`, and the standard mathematics/table packages is required.

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error NHDF_v0.3.tex
```

The packaged PDF was rendered and visually inspected page-by-page after compilation. Build auxiliary files are intentionally not included in the archive.
