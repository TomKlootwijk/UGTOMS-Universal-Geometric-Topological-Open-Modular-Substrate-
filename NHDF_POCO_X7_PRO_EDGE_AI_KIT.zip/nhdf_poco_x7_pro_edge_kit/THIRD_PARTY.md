# Third-party references and licenses

- Qwen/Qwen2.5-14B-Instruct and its official GGUF repository are published under
  Apache-2.0.  This kit does not include model weights.
- llama.cpp is fetched separately by the user.  Its license and the license of
  all transitive components apply to any built runtime.
- Android NDK, Vulkan headers/tools, PyTorch, Transformers, PEFT, safetensors,
  NumPy, and other dependencies retain their own licenses.

The code authored for this kit is provided under the MIT License in `LICENSE`.
