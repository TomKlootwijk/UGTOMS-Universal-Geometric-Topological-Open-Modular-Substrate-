#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
METRICS = ROOT / "metrics"

bf16_gb = 14.7696896 * 2
rows = [
    ("BF16 source", bf16_gb, "theoretical from 14.7696896B parameters"),
    ("Q8_0 official GGUF", 15.7, "official Hugging Face model page"),
    ("Q6_K official GGUF", 12.1, "official Hugging Face model page"),
    ("Q5_K_M official GGUF", 10.5, "official Hugging Face model page"),
    ("Q4_K_M official GGUF", 8.99, "official Hugging Face model page"),
    ("Q3_K_M official GGUF", 7.34, "official Hugging Face model page"),
    ("Q2_K official GGUF", 5.77, "official Hugging Face model page"),
]
for label, filename in [
    ("NHDF-MP3.15 safe target", "nhdf_mp315_estimate.json"),
    ("NHDF-MP2.75 balanced target", "nhdf_mp275_estimate.json"),
    ("NHDF-MP2.35 aggressive target", "nhdf_mp235_estimate.json"),
]:
    d = json.loads((METRICS / filename).read_text())
    rows.append((label, d["estimated_file_gb_decimal"], "format estimator; not measured model quality"))

with (METRICS / "model_size_comparison.csv").open("w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["variant", "size_gb_decimal", "compression_vs_bf16", "status"])
    for label, size, status in rows:
        w.writerow([label, f"{size:.4f}", f"{bf16_gb/size:.3f}", status])

balanced = json.loads((METRICS / "nhdf_mp275_estimate.json").read_text())
weight_gib = balanced["estimated_file_gib"]
mem = [
    ("NHDF packed weights", weight_gib, "estimated resident model arena"),
    ("Q8 KV cache, 4096", 384 / 1024, "from Qwen GQA config"),
    ("activations and compute scratch", 0.75, "planning allowance; measure on device"),
    ("Vulkan/runtime descriptors", 0.12, "planning allowance"),
    ("tokenizer/UI/native heap", 0.18, "planning allowance"),
    ("in-process safety margin", 0.35, "planning allowance"),
]
with (METRICS / "memory_budget_balanced.csv").open("w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["region", "gib", "basis"])
    w.writerows(mem)
    w.writerow(["TOTAL", sum(x[1] for x in mem), "target process RSS envelope"])

with (METRICS / "decode_roofline.csv").open("w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["variant", "weight_gb", "sustained_bandwidth_gbs", "efficiency", "estimated_tps"])
    variants = {"Q2_K": 5.77, "NHDF-MP2.75": balanced["estimated_file_gb_decimal"]}
    for name, size in variants.items():
        for bw in (25, 35, 45, 55):
            for eff in (0.45, 0.55):
                w.writerow([name, size, bw, eff, bw * eff / size])

with (METRICS / "scaling_table.csv").open("w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["parameters_billion", "effective_bpw", "estimated_pack_gb", "decode_tps_at_40GBs_50pct"])
    for params in (3, 7, 14.7696896, 32):
        for bpw in (2.2, 2.69, 3.2):
            size = params * bpw / 8
            tps = 40 * 0.5 / size
            w.writerow([params, bpw, size, tps])
