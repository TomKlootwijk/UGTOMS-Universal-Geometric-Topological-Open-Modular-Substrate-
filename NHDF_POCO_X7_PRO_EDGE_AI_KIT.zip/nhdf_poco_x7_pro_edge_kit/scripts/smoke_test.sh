#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

# The default path is deliberately offline-safe: it uses the current Python
# environment and imports the package from the repository.  Set
# NHDF_INSTALL=1 to exercise an editable installation when package indexes (or
# a populated wheel cache) are available.
if [[ "${NHDF_INSTALL:-0}" == "1" ]]; then
  python -m pip install --no-build-isolation -e '.[dev]'
fi
export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}"

python -m pytest -q
python -m nhdf_edge.toy --out-dir samples
python -m nhdf_edge.inspect_pack samples/toy_qwenish.nhdfpack --verify --verify-hash
python -m nhdf_edge.estimate \
  --config configs/qwen2_5_14b_config.json \
  --profile configs/qwen2_5_14b_nhdf_mp275.yaml \
  --json-out metrics/nhdf_mp275_estimate.json \
  --csv-out metrics/nhdf_mp275_tensor_plan.csv
